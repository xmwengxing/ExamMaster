#!/usr/bin/env node

/**
 * 检查和修复管理员账号脚本
 * 用于验证服务器数据库中的超级管理员账号是否存在
 * 如果不存在，则创建默认的超级管理员账号
 */

import { Pool } from 'pg';
import bcrypt from 'bcryptjs';
import dotenv from 'dotenv';

// 加载环境变量
dotenv.config();

// 数据库连接配置
const pool = new Pool({
  host: process.env.DB_HOST || 'localhost',
  port: process.env.DB_PORT || 5432,
  database: process.env.DB_NAME || 'edumaster',
  user: process.env.DB_USER || 'edumaster_user',
  password: process.env.DB_PASSWORD
});

// 颜色输出
const colors = {
  reset: '\x1b[0m',
  green: '\x1b[32m',
  red: '\x1b[31m',
  yellow: '\x1b[33m',
  blue: '\x1b[34m',
  cyan: '\x1b[36m'
};

function log(message, type = 'info') {
  const timestamp = new Date().toISOString();
  const prefix = {
    success: `${colors.green}✓${colors.reset}`,
    error: `${colors.red}✗${colors.reset}`,
    warning: `${colors.yellow}⚠${colors.reset}`,
    info: `${colors.blue}ℹ${colors.reset}`
  }[type];
  
  console.log(`${prefix} [${timestamp}] ${message}`);
}

async function checkDatabaseConnection() {
  log('检查数据库连接...', 'info');
  try {
    const client = await pool.connect();
    log('数据库连接成功', 'success');
    client.release();
    return true;
  } catch (error) {
    log(`数据库连接失败: ${error.message}`, 'error');
    return false;
  }
}

async function checkTablesExist() {
  log('检查数据表是否存在...', 'info');
  try {
    const result = await pool.query(`
      SELECT table_name 
      FROM information_schema.tables 
      WHERE table_schema = 'public' AND table_name = 'users'
    `);
    
    if (result.rows.length === 0) {
      log('users 表不存在！需要先运行数据库初始化脚本', 'error');
      return false;
    }
    
    log('users 表存在', 'success');
    return true;
  } catch (error) {
    log(`检查表失败: ${error.message}`, 'error');
    return false;
  }
}

async function checkAdminExists() {
  log('检查超级管理员账号...', 'info');
  try {
    const result = await pool.query(
      "SELECT id, phone, role, real_name FROM users WHERE phone = 'admin' AND role = 'ADMIN'"
    );
    
    if (result.rows.length > 0) {
      const admin = result.rows[0];
      log(`超级管理员账号已存在`, 'success');
      log(`  ID: ${admin.id}`, 'info');
      log(`  手机号: ${admin.phone}`, 'info');
      log(`  角色: ${admin.role}`, 'info');
      log(`  姓名: ${admin.real_name || '未设置'}`, 'info');
      return true;
    } else {
      log('超级管理员账号不存在', 'warning');
      return false;
    }
  } catch (error) {
    log(`检查管理员账号失败: ${error.message}`, 'error');
    return false;
  }
}

async function createDefaultAdmin() {
  log('创建默认超级管理员账号...', 'info');
  
  const adminData = {
    id: 'admin-' + Date.now(),
    phone: 'admin',
    password: 'admin',
    role: 'ADMIN',
    realName: '超级管理员',
    nickname: '管理员',
    permissions: JSON.stringify({
      dashboard: true,
      studentManagement: true,
      bankManagement: true,
      examPublish: true,
      practicalPublish: true,
      supervision: true,
      discussionManagement: true,
      tagManagement: true,
      systemSettings: true
    })
  };
  
  try {
    // 加密密码
    const hashedPassword = await bcrypt.hash(adminData.password, 10);
    
    // 插入管理员账号
    await pool.query(
      `INSERT INTO users (
        id, phone, password, role, real_name, nickname, permissions, created_at, updated_at
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)`,
      [
        adminData.id,
        adminData.phone,
        hashedPassword,
        adminData.role,
        adminData.realName,
        adminData.nickname,
        adminData.permissions
      ]
    );
    
    log('超级管理员账号创建成功！', 'success');
    log(`${colors.cyan}═══════════════════════════════════════${colors.reset}`, 'info');
    log(`${colors.cyan}  账号: admin${colors.reset}`, 'info');
    log(`${colors.cyan}  密码: admin${colors.reset}`, 'info');
    log(`${colors.cyan}  ⚠️  请立即登录并修改密码！${colors.reset}`, 'warning');
    log(`${colors.cyan}═══════════════════════════════════════${colors.reset}`, 'info');
    
    return true;
  } catch (error) {
    log(`创建管理员账号失败: ${error.message}`, 'error');
    return false;
  }
}

async function testAdminLogin() {
  log('测试管理员账号登录...', 'info');
  try {
    const result = await pool.query(
      "SELECT id, phone, password, role FROM users WHERE phone = 'admin' AND role = 'ADMIN'"
    );
    
    if (result.rows.length === 0) {
      log('管理员账号不存在', 'error');
      return false;
    }
    
    const admin = result.rows[0];
    const passwordMatch = await bcrypt.compare('admin', admin.password);
    
    if (passwordMatch) {
      log('管理员账号密码验证成功', 'success');
      return true;
    } else {
      log('管理员账号密码验证失败', 'error');
      return false;
    }
  } catch (error) {
    log(`测试登录失败: ${error.message}`, 'error');
    return false;
  }
}

async function checkAllTables() {
  log('检查所有数据表...', 'info');
  try {
    const result = await pool.query(`
      SELECT table_name 
      FROM information_schema.tables 
      WHERE table_schema = 'public'
      ORDER BY table_name
    `);
    
    const expectedTables = [
      'users', 'banks', 'questions', 'exams', 'exam_history',
      'practice_records', 'mistakes', 'favorites', 'notes',
      'srs_records', 'daily_progress', 'tags', 'question_tags',
      'discussions', 'comments', 'discussion_likes', 'ai_analysis',
      'practical_tasks', 'practical_records', 'login_logs',
      'audit_logs', 'system_config', 'system_config_kv'
    ];
    
    const actualTables = result.rows.map(r => r.table_name);
    const missingTables = expectedTables.filter(t => !actualTables.includes(t));
    
    if (missingTables.length > 0) {
      log(`缺失的数据表 (${missingTables.length}个):`, 'warning');
      missingTables.forEach(table => {
        log(`  - ${table}`, 'warning');
      });
      return false;
    } else {
      log(`所有 ${expectedTables.length} 个数据表都存在`, 'success');
      return true;
    }
  } catch (error) {
    log(`检查数据表失败: ${error.message}`, 'error');
    return false;
  }
}

async function getUserCount() {
  log('统计用户数量...', 'info');
  try {
    const result = await pool.query('SELECT COUNT(*) as count FROM users');
    const count = parseInt(result.rows[0].count);
    log(`当前用户总数: ${count}`, 'info');
    
    const adminResult = await pool.query("SELECT COUNT(*) as count FROM users WHERE role = 'ADMIN'");
    const adminCount = parseInt(adminResult.rows[0].count);
    log(`管理员数量: ${adminCount}`, 'info');
    
    const studentResult = await pool.query("SELECT COUNT(*) as count FROM users WHERE role = 'STUDENT'");
    const studentCount = parseInt(studentResult.rows[0].count);
    log(`学员数量: ${studentCount}`, 'info');
    
    return { total: count, admin: adminCount, student: studentCount };
  } catch (error) {
    log(`统计用户数量失败: ${error.message}`, 'error');
    return null;
  }
}

async function main() {
  console.log(`
╔═══════════════════════════════════════════════════════════╗
║                                                           ║
║          EduMaster 管理员账号检查和修复工具               ║
║                                                           ║
╚═══════════════════════════════════════════════════════════╝
  `);

  try {
    // 1. 检查数据库连接
    const connected = await checkDatabaseConnection();
    if (!connected) {
      log('无法连接到数据库，请检查配置', 'error');
      process.exit(1);
    }

    // 2. 检查所有数据表
    const tablesExist = await checkAllTables();
    if (!tablesExist) {
      log('数据表不完整，可能需要重新运行数据库初始化脚本', 'warning');
    }

    // 3. 检查 users 表
    const usersTableExists = await checkTablesExist();
    if (!usersTableExists) {
      log('users 表不存在，无法继续', 'error');
      process.exit(1);
    }

    // 4. 统计用户数量
    await getUserCount();

    // 5. 检查管理员账号
    const adminExists = await checkAdminExists();
    
    if (!adminExists) {
      log('需要创建默认管理员账号', 'warning');
      const created = await createDefaultAdmin();
      
      if (created) {
        // 测试登录
        await testAdminLogin();
      } else {
        log('创建管理员账号失败', 'error');
        process.exit(1);
      }
    } else {
      // 测试现有管理员账号
      const loginSuccess = await testAdminLogin();
      if (!loginSuccess) {
        log('管理员账号存在但密码验证失败，可能需要重置密码', 'warning');
      }
    }

    log('\n检查完成！', 'success');
    process.exit(0);
  } catch (error) {
    log(`发生错误: ${error.message}`, 'error');
    console.error(error);
    process.exit(1);
  } finally {
    await pool.end();
  }
}

// 执行主函数
main();
