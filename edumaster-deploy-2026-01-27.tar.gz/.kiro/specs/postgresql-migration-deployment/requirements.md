# 需求文档：PostgreSQL 数据库迁移与服务器部署

## 简介

将现有的 EduMaster 刷题系统从 SQLite 数据库迁移到 PostgreSQL，并部署到生产服务器。该系统是一个全栈教育平台，包含题库管理、考试系统、学员管理、讨论区等功能。

## 术语表

- **System**: EduMaster 刷题系统
- **Database**: PostgreSQL 数据库
- **Server**: 生产服务器（CentOS 7.8）
- **Migration**: 数据库迁移过程
- **Client**: 前端应用（React + Vite）
- **API_Server**: 后端服务器（Express + Node.js）
- **Docker**: 容器化部署工具
- **Nginx**: Web 服务器和反向代理
- **PM2**: Node.js 进程管理器

## 需求

### 需求 1：数据库架构迁移

**用户故事：** 作为开发者，我希望将 SQLite 数据库架构迁移到 PostgreSQL，以便获得更好的性能和并发支持。

#### 验收标准

1. WHEN 创建 PostgreSQL 数据库架构时，THE System SHALL 保留所有现有表结构和字段
2. WHEN 迁移数据类型时，THE System SHALL 将 SQLite 数据类型正确映射到 PostgreSQL 数据类型
3. WHEN 创建索引时，THE System SHALL 为所有外键和常用查询字段创建索引
4. WHEN 处理 JSON 字段时，THE System SHALL 使用 PostgreSQL 的 JSONB 类型替代 TEXT 类型
5. WHEN 设置主键和外键约束时，THE System SHALL 确保数据完整性

### 需求 2：数据迁移

**用户故事：** 作为系统管理员，我希望将现有 SQLite 数据库中的所有数据迁移到 PostgreSQL，以便保留历史数据。

#### 验收标准

1. WHEN 导出 SQLite 数据时，THE System SHALL 保持数据格式和编码正确
2. WHEN 导入数据到 PostgreSQL 时，THE System SHALL 处理字符编码问题（UTF-8）
3. WHEN 迁移 JSON 字段时，THE System SHALL 验证 JSON 格式的有效性
4. WHEN 迁移完成后，THE System SHALL 验证数据完整性和记录数量
5. IF 迁移过程中出现错误，THEN THE System SHALL 记录错误日志并支持回滚

### 需求 3：代码适配

**用户故事：** 作为开发者，我希望修改应用代码以支持 PostgreSQL，以便系统能够正常运行。

#### 验收标准

1. WHEN 替换数据库驱动时，THE System SHALL 使用 pg（node-postgres）替代 sqlite3
2. WHEN 修改 SQL 查询时，THE System SHALL 使用 PostgreSQL 语法（如 $1, $2 参数占位符）
3. WHEN 处理事务时，THE System SHALL 使用 PostgreSQL 的事务机制
4. WHEN 处理 JSON 字段时，THE System SHALL 使用 JSONB 操作符
5. WHEN 处理日期时间时，THE System SHALL 使用 PostgreSQL 的 TIMESTAMP 类型

### 需求 4：连接池和性能优化

**用户故事：** 作为系统架构师，我希望实现数据库连接池，以便提高系统性能和并发处理能力。

#### 验收标准

1. WHEN 初始化数据库连接时，THE System SHALL 创建连接池而非单一连接
2. WHEN 配置连接池时，THE System SHALL 设置合理的最小和最大连接数
3. WHEN 查询执行完毕时，THE System SHALL 自动释放连接回连接池
4. WHEN 连接池耗尽时，THE System SHALL 等待可用连接或返回超时错误
5. WHEN 应用关闭时，THE System SHALL 优雅地关闭所有数据库连接

### 需求 5：Docker 容器化

**用户故事：** 作为运维工程师，我希望使用 Docker 部署应用，以便简化部署流程和环境管理。

#### 验收标准

1. WHEN 创建 Dockerfile 时，THE System SHALL 使用多阶段构建优化镜像大小
2. WHEN 配置 docker-compose 时，THE System SHALL 包含 PostgreSQL、API 服务器和 Nginx
3. WHEN 启动容器时，THE System SHALL 自动初始化数据库架构
4. WHEN 配置环境变量时，THE System SHALL 使用 .env 文件管理敏感信息
5. WHEN 配置数据持久化时，THE System SHALL 使用 Docker volumes 保存数据库数据

### 需求 6：Nginx 反向代理配置

**用户故事：** 作为运维工程师，我希望配置 Nginx 作为反向代理，以便处理 HTTPS 和静态文件服务。

#### 验收标准

1. WHEN 配置 Nginx 时，THE System SHALL 监听 80 和 443 端口
2. WHEN 处理 HTTPS 请求时，THE System SHALL 使用有效的 SSL 证书
3. WHEN 代理 API 请求时，THE System SHALL 转发到后端 API 服务器
4. WHEN 服务静态文件时，THE System SHALL 直接从构建目录提供前端资源
5. WHEN 配置缓存时，THE System SHALL 为静态资源设置合理的缓存策略

### 需求 7：服务器部署

**用户故事：** 作为运维工程师，我希望将应用部署到生产服务器，以便用户可以访问系统。

#### 验收标准

1. WHEN 部署到服务器时，THE System SHALL 不影响服务器上的其他网站项目
2. WHEN 配置域名时，THE System SHALL 正确解析 exammaster.zzzjl.com
3. WHEN 启动服务时，THE System SHALL 使用 PM2 管理 Node.js 进程
4. WHEN 配置防火墙时，THE System SHALL 开放必要的端口（80, 443, 5432）
5. WHEN 配置自动启动时，THE System SHALL 在服务器重启后自动启动服务

### 需求 8：数据库备份和恢复

**用户故事：** 作为系统管理员，我希望实现数据库备份机制，以便在数据丢失时能够恢复。

#### 验收标准

1. WHEN 执行备份时，THE System SHALL 使用 pg_dump 导出完整数据库
2. WHEN 配置定时备份时，THE System SHALL 每天自动备份数据库
3. WHEN 保存备份文件时，THE System SHALL 保留最近 7 天的备份
4. WHEN 执行恢复时，THE System SHALL 使用 pg_restore 恢复数据库
5. WHEN 备份失败时，THE System SHALL 发送通知给管理员

### 需求 9：监控和日志

**用户故事：** 作为运维工程师，我希望实现系统监控和日志记录，以便及时发现和解决问题。

#### 验收标准

1. WHEN 应用运行时，THE System SHALL 记录所有 API 请求和响应
2. WHEN 发生错误时，THE System SHALL 记录详细的错误堆栈信息
3. WHEN 监控数据库时，THE System SHALL 记录连接池状态和查询性能
4. WHEN 日志文件过大时，THE System SHALL 自动轮转日志文件
5. WHEN 系统资源不足时，THE System SHALL 发送告警通知

### 需求 10：性能优化

**用户故事：** 作为开发者，我希望优化系统性能，以便提供更好的用户体验。

#### 验收标准

1. WHEN 执行批量操作时，THE System SHALL 使用事务和批量插入
2. WHEN 查询大量数据时，THE System SHALL 实现分页查询
3. WHEN 处理 JSON 字段时，THE System SHALL 使用 JSONB 索引加速查询
4. WHEN 缓存数据时，THE System SHALL 使用 Redis 缓存热点数据（可选）
5. WHEN 优化查询时，THE System SHALL 使用 EXPLAIN ANALYZE 分析查询计划

### 需求 11：安全加固

**用户故事：** 作为安全工程师，我希望加固系统安全，以便保护用户数据和系统资源。

#### 验收标准

1. WHEN 配置数据库时，THE System SHALL 使用强密码和限制远程访问
2. WHEN 处理用户输入时，THE System SHALL 防止 SQL 注入攻击
3. WHEN 传输敏感数据时，THE System SHALL 使用 HTTPS 加密
4. WHEN 存储密码时，THE System SHALL 使用 bcrypt 加密
5. WHEN 配置 CORS 时，THE System SHALL 限制允许的来源域名

### 需求 12：CI/CD 部署流程

**用户故事：** 作为开发者，我希望建立自动化部署流程，以便快速发布新版本。

#### 验收标准

1. WHEN 推送代码到 GitHub 时，THE System SHALL 自动触发构建流程
2. WHEN 构建完成时，THE System SHALL 自动运行测试
3. WHEN 测试通过时，THE System SHALL 自动部署到服务器
4. WHEN 部署失败时，THE System SHALL 自动回滚到上一个版本
5. WHEN 部署成功时，THE System SHALL 发送通知给开发团队
