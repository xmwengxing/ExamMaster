# 设计文档：PostgreSQL 数据库迁移与服务器部署

## 概述

本设计文档描述了将 EduMaster 刷题系统从 SQLite 迁移到 PostgreSQL 并部署到生产服务器的完整方案。该系统是一个全栈教育平台，包含题库管理、考试系统、学员管理、讨论区等功能。

### 迁移目标

1. **数据库升级**：从 SQLite 迁移到 PostgreSQL，提升并发性能和数据完整性
2. **容器化部署**：使用 Docker 实现标准化部署流程
3. **生产环境配置**：配置 Nginx 反向代理、SSL 证书、域名解析
4. **性能优化**：实现连接池、查询优化、缓存策略
5. **运维保障**：实现监控、日志、备份、自动化部署

### 技术栈

- **数据库**：PostgreSQL 14+
- **后端**：Node.js 18+ + Express 5
- **前端**：React 19 + Vite 6
- **数据库驱动**：node-postgres (pg)
- **容器化**：Docker + Docker Compose
- **Web 服务器**：Nginx
- **进程管理**：PM2
- **服务器**：CentOS 7.8

## 架构设计

### 系统架构图

```
[用户浏览器]
     |
     | HTTPS (443)
     v
[Nginx 反向代理]
     |
     +---> [静态文件] (React 构建产物)
     |
     +---> [API 请求] --> [Node.js API 服务器] (3001)
                              |
                              v
                         [PostgreSQL] (5432)
                              |
                              v
                         [数据卷持久化]
```

### 部署架构

```
服务器: 47.104.173.139
域名: exammaster.zzzjl.com

/www/wwwroot/exammaster.zzzjl.com/
├── docker-compose.yml          # Docker 编排配置
├── .env                        # 环境变量
├── nginx/
│   └── nginx.conf             # Nginx 配置
├── backend/
│   ├── Dockerfile             # 后端镜像
│   ├── server.js              # API 服务器
│   └── package.json
├── frontend/
│   └── dist/                  # 前端构建产物
└── postgres/
    ├── init.sql               # 数据库初始化脚本
    └── data/                  # 数据持久化目录
```

## 组件和接口

### 1. 数据库层（PostgreSQL）

#### 数据库连接配置

```javascript
// db.js - 数据库连接池配置
import { Pool } from 'pg';

const pool = new Pool({
  host: process.env.DB_HOST || 'localhost',
  port: process.env.DB_PORT || 5432,
  database: process.env.DB_NAME || 'edumaster',
  user: process.env.DB_USER || 'edumaster_user',
  password: process.env.DB_PASSWORD,
  
  // 连接池配置
  min: 2,                    // 最小连接数
  max: 20,                   // 最大连接数
  idleTimeoutMillis: 30000,  // 空闲连接超时时间
  connectionTimeoutMillis: 2000, // 连接超时时间
});

// 错误处理
pool.on('error', (err, client) => {
  console.error('数据库连接池错误:', err);
});

export default pool;
```


#### 数据库架构迁移

**SQLite 到 PostgreSQL 数据类型映射**：

| SQLite 类型 | PostgreSQL 类型 | 说明 |
|------------|----------------|------|
| TEXT | VARCHAR/TEXT | 文本字段 |
| INTEGER | INTEGER/BIGINT | 整数字段 |
| REAL | NUMERIC/DOUBLE PRECISION | 浮点数 |
| TEXT (JSON) | JSONB | JSON 数据，使用 JSONB 提升性能 |
| TEXT (日期) | TIMESTAMP | 日期时间字段 |

**关键表结构示例**：

```sql
-- 用户表
CREATE TABLE users (
  id VARCHAR(255) PRIMARY KEY,
  phone VARCHAR(50) UNIQUE NOT NULL,
  password VARCHAR(255) NOT NULL,
  role VARCHAR(20) NOT NULL,
  real_name VARCHAR(100),
  nickname VARCHAR(100),
  avatar TEXT,
  id_card VARCHAR(50),
  school VARCHAR(200),
  education_type VARCHAR(50),
  education_level VARCHAR(50),
  major VARCHAR(100),
  company VARCHAR(200),
  custom_fields JSONB,
  student_perms JSONB,
  allowed_bank_ids JSONB,
  accuracy NUMERIC(5,2),
  mistake_count INTEGER DEFAULT 0,
  daily_goal INTEGER DEFAULT 20,
  last_login TIMESTAMP,
  permissions JSONB,
  deepseek_api_key TEXT,
  login_history JSONB,
  total_online_time INTEGER DEFAULT 0,
  class_name VARCHAR(100),
  last_activity TIMESTAMP,
  gender VARCHAR(10),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 创建索引
CREATE INDEX idx_users_phone ON users(phone);
CREATE INDEX idx_users_role ON users(role);
CREATE INDEX idx_users_last_activity ON users(last_activity);

-- 题目表
CREATE TABLE questions (
  id VARCHAR(255) PRIMARY KEY,
  bank_id VARCHAR(255) NOT NULL,
  type VARCHAR(50) NOT NULL,
  content TEXT NOT NULL,
  options JSONB,
  answer JSONB,
  explanation TEXT,
  chapter VARCHAR(200),
  blanks JSONB,
  reference_answer TEXT,
  ai_grading_enabled BOOLEAN DEFAULT FALSE,
  tags JSONB,
  sort_order INTEGER DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (bank_id) REFERENCES banks(id) ON DELETE CASCADE
);

-- 创建索引
CREATE INDEX idx_questions_bank_id ON questions(bank_id);
CREATE INDEX idx_questions_type ON questions(type);
CREATE INDEX idx_questions_sort_order ON questions(bank_id, sort_order);
CREATE INDEX idx_questions_tags ON questions USING GIN(tags);
```

### 2. API 服务器层（Node.js + Express）

#### 数据库查询适配

**SQLite 查询（旧）**：
```javascript
db.get("SELECT * FROM users WHERE phone = ? AND role = ?", [phone, role], callback);
```

**PostgreSQL 查询（新）**：
```javascript
const result = await pool.query(
  'SELECT * FROM users WHERE phone = $1 AND role = $2',
  [phone, role]
);
const user = result.rows[0];
```

#### 事务处理

```javascript
// 事务处理示例
async function batchImportQuestions(bankId, questions) {
  const client = await pool.connect();
  
  try {
    await client.query('BEGIN');
    
    for (const question of questions) {
      await client.query(
        `INSERT INTO questions (id, bank_id, type, content, options, answer, explanation)
         VALUES ($1, $2, $3, $4, $5, $6, $7)`,
        [question.id, bankId, question.type, question.content, 
         JSON.stringify(question.options), JSON.stringify(question.answer), 
         question.explanation]
      );
    }
    
    // 更新题库题目数量
    await client.query(
      'UPDATE banks SET question_count = question_count + $1 WHERE id = $2',
      [questions.length, bankId]
    );
    
    await client.query('COMMIT');
    return { success: true, inserted: questions.length };
    
  } catch (error) {
    await client.query('ROLLBACK');
    throw error;
  } finally {
    client.release();
  }
}
```


### 3. Docker 容器化

#### Dockerfile（后端）

```dockerfile
# 多阶段构建
FROM node:18-alpine AS builder

WORKDIR /app

# 复制依赖文件
COPY package*.json ./

# 安装依赖
RUN npm ci --only=production

# 生产阶段
FROM node:18-alpine

WORKDIR /app

# 复制依赖
COPY --from=builder /app/node_modules ./node_modules

# 复制应用代码
COPY . .

# 暴露端口
EXPOSE 3001

# 健康检查
HEALTHCHECK --interval=30s --timeout=3s --start-period=40s \
  CMD node -e "require('http').get('http://localhost:3001/api/health', (r) => {process.exit(r.statusCode === 200 ? 0 : 1)})"

# 启动应用
CMD ["node", "server.js"]
```

#### docker-compose.yml

```yaml
version: '3.8'

services:
  postgres:
    image: postgres:14-alpine
    container_name: edumaster_postgres
    environment:
      POSTGRES_DB: ${DB_NAME}
      POSTGRES_USER: ${DB_USER}
      POSTGRES_PASSWORD: ${DB_PASSWORD}
      POSTGRES_INITDB_ARGS: "-E UTF8 --locale=C"
    volumes:
      - ./postgres/data:/var/lib/postgresql/data
      - ./postgres/init.sql:/docker-entrypoint-initdb.d/init.sql
    ports:
      - "5432:5432"
    restart: unless-stopped
    healthcheck:
      test: ["CMD-SHELL", "pg_isready -U ${DB_USER} -d ${DB_NAME}"]
      interval: 10s
      timeout: 5s
      retries: 5

  api:
    build:
      context: ./backend
      dockerfile: Dockerfile
    container_name: edumaster_api
    environment:
      NODE_ENV: production
      PORT: 3001
      DB_HOST: postgres
      DB_PORT: 5432
      DB_NAME: ${DB_NAME}
      DB_USER: ${DB_USER}
      DB_PASSWORD: ${DB_PASSWORD}
      JWT_SECRET: ${JWT_SECRET}
    volumes:
      - ./backend:/app
      - /app/node_modules
    ports:
      - "3001:3001"
    depends_on:
      postgres:
        condition: service_healthy
    restart: unless-stopped

  nginx:
    image: nginx:alpine
    container_name: edumaster_nginx
    volumes:
      - ./nginx/nginx.conf:/etc/nginx/nginx.conf:ro
      - ./frontend/dist:/usr/share/nginx/html:ro
      - ./nginx/ssl:/etc/nginx/ssl:ro
    ports:
      - "80:80"
      - "443:443"
    depends_on:
      - api
    restart: unless-stopped

volumes:
  postgres_data:
```

### 4. Nginx 配置

```nginx
# nginx.conf
user nginx;
worker_processes auto;
error_log /var/log/nginx/error.log warn;
pid /var/run/nginx.pid;

events {
    worker_connections 1024;
}

http {
    include /etc/nginx/mime.types;
    default_type application/octet-stream;

    log_format main '$remote_addr - $remote_user [$time_local] "$request" '
                    '$status $body_size "$http_referer" '
                    '"$http_user_agent" "$http_x_forwarded_for"';

    access_log /var/log/nginx/access.log main;

    sendfile on;
    tcp_nopush on;
    tcp_nodelay on;
    keepalive_timeout 65;
    types_hash_max_size 2048;
    client_max_body_size 50M;

    # Gzip 压缩
    gzip on;
    gzip_vary on;
    gzip_proxied any;
    gzip_comp_level 6;
    gzip_types text/plain text/css text/xml text/javascript 
               application/json application/javascript application/xml+rss;

    # HTTP 重定向到 HTTPS
    server {
        listen 80;
        server_name exammaster.zzzjl.com;
        return 301 https://$server_name$request_uri;
    }

    # HTTPS 服务器
    server {
        listen 443 ssl http2;
        server_name exammaster.zzzjl.com;

        # SSL 证书配置
        ssl_certificate /etc/nginx/ssl/cert.pem;
        ssl_certificate_key /etc/nginx/ssl/key.pem;
        ssl_protocols TLSv1.2 TLSv1.3;
        ssl_ciphers HIGH:!aNULL:!MD5;
        ssl_prefer_server_ciphers on;

        # 前端静态文件
        location / {
            root /usr/share/nginx/html;
            index index.html;
            try_files $uri $uri/ /index.html;
            
            # 缓存策略
            location ~* \.(js|css|png|jpg|jpeg|gif|ico|svg|woff|woff2|ttf|eot)$ {
                expires 1y;
                add_header Cache-Control "public, immutable";
            }
        }

        # API 代理
        location /api/ {
            proxy_pass http://api:3001;
            proxy_http_version 1.1;
            proxy_set_header Upgrade $http_upgrade;
            proxy_set_header Connection 'upgrade';
            proxy_set_header Host $host;
            proxy_set_header X-Real-IP $remote_addr;
            proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
            proxy_set_header X-Forwarded-Proto $scheme;
            proxy_cache_bypass $http_upgrade;
            proxy_read_timeout 300s;
            proxy_connect_timeout 75s;
        }
    }
}
```


## 数据模型

### 数据迁移策略

#### 方案选择

我们采用**分步迁移**策略，确保数据完整性和可回滚性：

1. **导出 SQLite 数据**：使用自定义脚本导出为 JSON 格式
2. **数据清洗**：处理编码问题、验证 JSON 字段
3. **导入 PostgreSQL**：使用事务批量导入
4. **数据验证**：对比记录数量和关键数据

#### 迁移脚本设计

```javascript
// migrate.js - 数据迁移脚本
import sqlite3 from 'sqlite3';
import { Pool } from 'pg';
import fs from 'fs/promises';

const sqliteDb = new sqlite3.Database('./edumaster.db');
const pgPool = new Pool({
  host: 'localhost',
  port: 5432,
  database: 'edumaster',
  user: 'edumaster_user',
  password: process.env.DB_PASSWORD,
});

// 表迁移顺序（考虑外键依赖）
const TABLES = [
  'users',
  'banks',
  'questions',
  'exams',
  'exam_history',
  'practice_records',
  'mistakes',
  'favorites',
  'notes',
  'srs_records',
  'daily_progress',
  'tags',
  'question_tags',
  'discussions',
  'comments',
  'discussion_likes',
  'ai_analysis',
  'practical_tasks',
  'practical_records',
  'login_logs',
  'audit_logs',
  'system_config',
  'system_config_kv'
];

async function migrateTable(tableName) {
  console.log(`开始迁移表: ${tableName}`);
  
  // 1. 从 SQLite 导出数据
  const rows = await new Promise((resolve, reject) => {
    sqliteDb.all(`SELECT * FROM ${tableName}`, (err, rows) => {
      if (err) reject(err);
      else resolve(rows || []);
    });
  });
  
  if (rows.length === 0) {
    console.log(`表 ${tableName} 无数据，跳过`);
    return { table: tableName, count: 0 };
  }
  
  // 2. 数据转换和清洗
  const cleanedRows = rows.map(row => cleanRow(row, tableName));
  
  // 3. 批量导入到 PostgreSQL
  const client = await pgPool.connect();
  try {
    await client.query('BEGIN');
    
    for (const row of cleanedRows) {
      const columns = Object.keys(row);
      const values = Object.values(row);
      const placeholders = columns.map((_, i) => `$${i + 1}`).join(', ');
      
      await client.query(
        `INSERT INTO ${tableName} (${columns.join(', ')}) 
         VALUES (${placeholders})
         ON CONFLICT DO NOTHING`,
        values
      );
    }
    
    await client.query('COMMIT');
    console.log(`表 ${tableName} 迁移完成: ${rows.length} 条记录`);
    return { table: tableName, count: rows.length };
    
  } catch (error) {
    await client.query('ROLLBACK');
    console.error(`表 ${tableName} 迁移失败:`, error);
    throw error;
  } finally {
    client.release();
  }
}

function cleanRow(row, tableName) {
  const cleaned = {};
  
  for (const [key, value] of Object.entries(row)) {
    // 处理 NULL 值
    if (value === null || value === undefined) {
      cleaned[key] = null;
      continue;
    }
    
    // 处理 JSON 字段
    if (isJsonField(tableName, key)) {
      try {
        // 验证 JSON 格式
        const parsed = typeof value === 'string' ? JSON.parse(value) : value;
        cleaned[key] = parsed;
      } catch (e) {
        console.warn(`JSON 解析失败: ${tableName}.${key}`, value);
        cleaned[key] = null;
      }
    }
    // 处理布尔值
    else if (typeof value === 'number' && (value === 0 || value === 1)) {
      cleaned[key] = value === 1;
    }
    // 处理日期时间
    else if (isDateField(tableName, key)) {
      cleaned[key] = value ? new Date(value).toISOString() : null;
    }
    // 其他字段直接复制
    else {
      cleaned[key] = value;
    }
  }
  
  return cleaned;
}

// 主迁移流程
async function migrate() {
  console.log('开始数据迁移...');
  const results = [];
  
  for (const table of TABLES) {
    try {
      const result = await migrateTable(table);
      results.push(result);
    } catch (error) {
      console.error(`迁移失败，停止迁移`);
      throw error;
    }
  }
  
  // 输出迁移报告
  console.log('\n迁移完成！');
  console.table(results);
  
  // 验证数据
  await validateMigration();
}

async function validateMigration() {
  console.log('\n开始验证数据...');
  
  for (const table of TABLES) {
    const sqliteCount = await new Promise((resolve, reject) => {
      sqliteDb.get(`SELECT COUNT(*) as count FROM ${table}`, (err, row) => {
        if (err) reject(err);
        else resolve(row.count);
      });
    });
    
    const pgResult = await pgPool.query(`SELECT COUNT(*) as count FROM ${table}`);
    const pgCount = parseInt(pgResult.rows[0].count);
    
    if (sqliteCount !== pgCount) {
      console.error(`❌ 表 ${table} 数据不一致: SQLite=${sqliteCount}, PostgreSQL=${pgCount}`);
    } else {
      console.log(`✅ 表 ${table} 验证通过: ${pgCount} 条记录`);
    }
  }
}

// 执行迁移
migrate()
  .then(() => {
    console.log('迁移成功完成！');
    process.exit(0);
  })
  .catch(error => {
    console.error('迁移失败:', error);
    process.exit(1);
  });
```


## 正确性属性

*属性是一个特征或行为，应该在系统的所有有效执行中保持为真——本质上是关于系统应该做什么的形式化陈述。属性作为人类可读规范和机器可验证正确性保证之间的桥梁。*

### 数据库迁移属性

**属性 1：架构完整性保持**
*对于任意* SQLite 数据库架构，迁移到 PostgreSQL 后应该保留所有表名、字段名和字段数量
**验证：需求 1.1**

**属性 2：数据类型映射正确性**
*对于任意* SQLite 数据类型，映射函数应该返回符合映射规则的 PostgreSQL 数据类型
**验证：需求 1.2**

**属性 3：约束完整性**
*对于任意* 违反主键或外键约束的数据，PostgreSQL 应该拒绝插入操作
**验证：需求 1.5**

**属性 4：数据迁移往返一致性**
*对于任意* 表的数据，导出、清洗、导入后的记录数量和关键字段内容应该与原始数据一致
**验证：需求 2.1, 2.2, 2.4**

**属性 5：JSON 格式验证**
*对于任意* JSON 字段，如果格式无效应该被检测并处理（记录日志或设置为 NULL）
**验证：需求 2.3**

**属性 6：事务原子性**
*对于任意* 迁移操作，如果过程中发生错误，所有已执行的操作应该被回滚，数据库状态应该恢复到操作前
**验证：需求 2.5**

### 代码适配属性

**属性 7：事务一致性**
*对于任意* 使用事务的操作序列，如果中途失败应该回滚所有操作，如果成功应该提交所有操作
**验证：需求 3.3**

**属性 8：JSONB 查询正确性**
*对于任意* JSONB 字段和查询条件，使用 JSONB 操作符的查询结果应该与预期的 JSON 结构匹配
**验证：需求 3.4**

**属性 9：日期时间处理正确性**
*对于任意* 日期时间值，插入后查询应该返回相同的时间戳（考虑时区）
**验证：需求 3.5**

### 连接池属性

**属性 10：连接池资源管理**
*对于任意* 数据库查询操作，执行完毕后连接池的可用连接数应该恢复到执行前的状态
**验证：需求 4.3, 4.5**

### Nginx 代理属性

**属性 11：API 代理透明性**
*对于任意* API 请求，通过 Nginx 代理的响应应该与直接访问后端 API 的响应一致（除了代理添加的头信息）
**验证：需求 6.3**

**属性 12：静态文件一致性**
*对于任意* 静态文件请求，Nginx 返回的内容应该与构建目录中对应文件的内容完全一致
**验证：需求 6.4**

### 备份恢复属性

**属性 13：备份恢复往返一致性**
*对于任意* 数据库状态，执行备份然后恢复操作后，数据库的表结构和数据内容应该与备份前完全一致
**验证：需求 8.1, 8.4**

### 日志监控属性

**属性 14：日志完整性**
*对于任意* API 请求或错误事件，日志文件中应该有对应的记录，包含时间戳、请求信息和响应状态（或错误堆栈）
**验证：需求 9.1, 9.2**

### 性能优化属性

**属性 15：分页查询正确性**
*对于任意* 数据集和分页参数（page, pageSize），分页查询返回的记录应该是完整数据集的正确子集，且不重复不遗漏
**验证：需求 10.2**

**属性 16：缓存一致性（可选）**
*对于任意* 缓存的数据，如果数据库中的原始数据被更新，缓存应该被失效或更新，确保读取到的数据是最新的
**验证：需求 10.4**

### 安全属性

**属性 17：SQL 注入防御**
*对于任意* 包含 SQL 注入攻击载荷的用户输入，系统应该安全地处理（使用参数化查询），不执行恶意 SQL 代码
**验证：需求 11.2**


## 错误处理

### 数据库连接错误

```javascript
// 连接池错误处理
pool.on('error', (err, client) => {
  console.error('数据库连接池意外错误:', err);
  // 发送告警通知
  sendAlert('Database Pool Error', err.message);
});

// 查询错误处理
async function safeQuery(query, params) {
  try {
    const result = await pool.query(query, params);
    return { success: true, data: result.rows };
  } catch (error) {
    console.error('查询执行失败:', error);
    
    // 根据错误类型进行处理
    if (error.code === '23505') {
      // 唯一约束违反
      return { success: false, error: '数据已存在' };
    } else if (error.code === '23503') {
      // 外键约束违反
      return { success: false, error: '关联数据不存在' };
    } else if (error.code === 'ECONNREFUSED') {
      // 数据库连接被拒绝
      return { success: false, error: '数据库连接失败' };
    } else {
      // 其他错误
      return { success: false, error: '数据库操作失败' };
    }
  }
}
```

### 迁移错误处理

```javascript
// 迁移过程错误处理
async function migrateWithRetry(tableName, maxRetries = 3) {
  let attempt = 0;
  
  while (attempt < maxRetries) {
    try {
      await migrateTable(tableName);
      return { success: true };
    } catch (error) {
      attempt++;
      console.error(`表 ${tableName} 迁移失败 (尝试 ${attempt}/${maxRetries}):`, error);
      
      if (attempt >= maxRetries) {
        // 记录到错误日志
        await logMigrationError(tableName, error);
        return { success: false, error: error.message };
      }
      
      // 等待后重试
      await new Promise(resolve => setTimeout(resolve, 1000 * attempt));
    }
  }
}
```

### Docker 容器错误处理

```yaml
# docker-compose.yml 健康检查和重启策略
services:
  postgres:
    healthcheck:
      test: ["CMD-SHELL", "pg_isready -U ${DB_USER} -d ${DB_NAME}"]
      interval: 10s
      timeout: 5s
      retries: 5
      start_period: 30s
    restart: unless-stopped

  api:
    healthcheck:
      test: ["CMD", "node", "-e", "require('http').get('http://localhost:3001/api/health', (r) => {process.exit(r.statusCode === 200 ? 0 : 1)})"]
      interval: 30s
      timeout: 3s
      retries: 3
      start_period: 40s
    restart: unless-stopped
    depends_on:
      postgres:
        condition: service_healthy
```

### Nginx 错误页面

```nginx
# nginx.conf 错误页面配置
http {
    # 自定义错误页面
    error_page 404 /404.html;
    error_page 500 502 503 504 /50x.html;
    
    location = /404.html {
        root /usr/share/nginx/html;
        internal;
    }
    
    location = /50x.html {
        root /usr/share/nginx/html;
        internal;
    }
    
    # API 代理错误处理
    location /api/ {
        proxy_pass http://api:3001;
        
        # 超时配置
        proxy_connect_timeout 10s;
        proxy_send_timeout 60s;
        proxy_read_timeout 60s;
        
        # 错误处理
        proxy_intercept_errors on;
        error_page 502 503 504 = @api_error;
    }
    
    location @api_error {
        return 503 '{"error": "服务暂时不可用，请稍后重试"}';
        add_header Content-Type application/json;
    }
}
```

## 测试策略

### 双重测试方法

本项目采用**单元测试**和**属性测试**相结合的方式，确保全面的测试覆盖：

- **单元测试**：验证具体示例、边界情况和错误条件
- **属性测试**：验证跨所有输入的通用属性
- 两者互补且都是必需的，以实现全面覆盖

### 单元测试策略

单元测试专注于：
- 具体示例，展示正确行为
- 组件之间的集成点
- 边界情况和错误条件

**示例单元测试**：

```javascript
// tests/migration.test.js
import { describe, it, expect, beforeAll, afterAll } from 'vitest';
import { migrateTable, cleanRow } from '../migrate.js';
import sqlite3 from 'sqlite3';
import { Pool } from 'pg';

describe('数据迁移单元测试', () => {
  let sqliteDb, pgPool;
  
  beforeAll(async () => {
    // 设置测试数据库
    sqliteDb = new sqlite3.Database(':memory:');
    pgPool = new Pool({ /* test config */ });
  });
  
  afterAll(async () => {
    await pgPool.end();
    sqliteDb.close();
  });
  
  it('应该正确清洗 JSON 字段', () => {
    const row = {
      id: '1',
      options: '["A", "B", "C"]',
      answer: '"A"'
    };
    
    const cleaned = cleanRow(row, 'questions');
    
    expect(cleaned.options).toEqual(['A', 'B', 'C']);
    expect(cleaned.answer).toBe('A');
  });
  
  it('应该处理无效的 JSON 字段', () => {
    const row = {
      id: '1',
      options: 'invalid json'
    };
    
    const cleaned = cleanRow(row, 'questions');
    
    expect(cleaned.options).toBeNull();
  });
  
  it('应该正确转换布尔值', () => {
    const row = {
      id: '1',
      ai_grading_enabled: 1,
      is_visible: 0
    };
    
    const cleaned = cleanRow(row, 'questions');
    
    expect(cleaned.ai_grading_enabled).toBe(true);
    expect(cleaned.is_visible).toBe(false);
  });
});
```

### 属性测试策略

属性测试使用 [fast-check](https://github.com/dubzzz/fast-check) 库，每个测试运行最少 100 次迭代。

**属性测试配置**：
- 最小迭代次数：100
- 每个属性测试必须引用其设计文档属性
- 标签格式：**Feature: postgresql-migration-deployment, Property {number}: {property_text}**

**示例属性测试**：

```javascript
// tests/migration.property.test.js
import { describe, it } from 'vitest';
import fc from 'fast-check';
import { migrateTable, cleanRow } from '../migrate.js';

describe('数据迁移属性测试', () => {
  /**
   * Feature: postgresql-migration-deployment, Property 4: 数据迁移往返一致性
   * 对于任意表的数据，导出、清洗、导入后的记录数量和关键字段内容应该与原始数据一致
   */
  it('属性 4：数据迁移往返一致性', () => {
    fc.assert(
      fc.property(
        fc.array(fc.record({
          id: fc.string(),
          content: fc.string(),
          type: fc.constantFrom('SINGLE', 'MULTIPLE', 'JUDGE'),
          options: fc.array(fc.string()),
          answer: fc.string()
        })),
        async (questions) => {
          // 插入到 SQLite
          for (const q of questions) {
            await insertToSQLite(q);
          }
          
          // 迁移到 PostgreSQL
          await migrateTable('questions');
          
          // 验证记录数量
          const sqliteCount = await getSQLiteCount('questions');
          const pgCount = await getPostgreSQLCount('questions');
          expect(sqliteCount).toBe(pgCount);
          
          // 验证关键字段内容
          for (const q of questions) {
            const pgRow = await getPostgreSQLRow('questions', q.id);
            expect(pgRow.content).toBe(q.content);
            expect(pgRow.type).toBe(q.type);
          }
        }
      ),
      { numRuns: 100 }
    );
  });
  
  /**
   * Feature: postgresql-migration-deployment, Property 5: JSON 格式验证
   * 对于任意 JSON 字段，如果格式无效应该被检测并处理
   */
  it('属性 5：JSON 格式验证', () => {
    fc.assert(
      fc.property(
        fc.record({
          id: fc.string(),
          options: fc.oneof(
            fc.jsonValue(),  // 有效 JSON
            fc.string()      // 可能无效的字符串
          )
        }),
        (row) => {
          const cleaned = cleanRow(row, 'questions');
          
          // 如果原始值是有效 JSON，清洗后应该保持
          // 如果原始值是无效 JSON，清洗后应该是 null
          if (typeof row.options === 'string') {
            try {
              JSON.parse(row.options);
              expect(cleaned.options).not.toBeNull();
            } catch (e) {
              expect(cleaned.options).toBeNull();
            }
          }
        }
      ),
      { numRuns: 100 }
    );
  });
  
  /**
   * Feature: postgresql-migration-deployment, Property 17: SQL 注入防御
   * 对于任意包含 SQL 注入攻击载荷的用户输入，系统应该安全地处理
   */
  it('属性 17：SQL 注入防御', () => {
    fc.assert(
      fc.property(
        fc.string(),  // 任意字符串，可能包含 SQL 注入载荷
        async (userInput) => {
          // 尝试使用用户输入进行查询
          const result = await pool.query(
            'SELECT * FROM users WHERE phone = $1',
            [userInput]
          );
          
          // 查询应该成功执行（不抛出错误）
          // 且不应该执行任何恶意 SQL 代码
          expect(result).toBeDefined();
          
          // 验证数据库状态未被破坏
          const tableCount = await pool.query(
            "SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = 'public'"
          );
          expect(tableCount.rows[0].count).toBeGreaterThan(0);
        }
      ),
      { numRuns: 100 }
    );
  });
});
```

### 集成测试

```javascript
// tests/integration.test.js
describe('端到端集成测试', () => {
  it('应该完成完整的迁移流程', async () => {
    // 1. 准备 SQLite 测试数据
    await setupSQLiteTestData();
    
    // 2. 执行迁移
    const result = await migrate();
    expect(result.success).toBe(true);
    
    // 3. 验证 PostgreSQL 数据
    await validatePostgreSQLData();
    
    // 4. 测试 API 功能
    const apiResponse = await fetch('http://localhost:3001/api/questions');
    expect(apiResponse.status).toBe(200);
    
    // 5. 测试前端访问
    const frontendResponse = await fetch('http://localhost');
    expect(frontendResponse.status).toBe(200);
  });
});
```

### 性能测试

```javascript
// tests/performance.test.js
describe('性能测试', () => {
  it('连接池应该支持高并发查询', async () => {
    const concurrentQueries = 100;
    const queries = Array(concurrentQueries).fill(null).map(() => 
      pool.query('SELECT * FROM users LIMIT 1')
    );
    
    const start = Date.now();
    await Promise.all(queries);
    const duration = Date.now() - start;
    
    // 100 个并发查询应该在 1 秒内完成
    expect(duration).toBeLessThan(1000);
  });
  
  it('批量插入应该比单条插入快', async () => {
    const testData = Array(1000).fill(null).map((_, i) => ({
      id: `test-${i}`,
      content: `Test question ${i}`
    }));
    
    // 单条插入
    const singleStart = Date.now();
    for (const data of testData) {
      await pool.query('INSERT INTO questions (id, content) VALUES ($1, $2)', [data.id, data.content]);
    }
    const singleDuration = Date.now() - singleStart;
    
    // 批量插入
    const batchStart = Date.now();
    await batchInsertQuestions(testData);
    const batchDuration = Date.now() - batchStart;
    
    // 批量插入应该至少快 5 倍
    expect(batchDuration * 5).toBeLessThan(singleDuration);
  });
});
```

