# 设计文档 - Server.js 模块化重构

## 概述

本设计文档描述了如何将现有的 4100+ 行 server.js 文件重构为模块化架构，同时保持向后兼容性和系统性能。重构将采用分层架构模式，将代码按功能域和职责进行组织。

### 设计目标

1. **可维护性**: 通过模块化降低代码复杂度，使每个模块职责单一
2. **可扩展性**: 便于添加新功能而不影响现有代码
3. **可测试性**: 每个模块可独立测试
4. **向后兼容**: 保持所有 API 端点和响应格式不变
5. **性能保持**: 重构不应降低系统性能

## 架构设计

### 整体架构

采用经典的三层架构模式：

```
┌─────────────────────────────────────────┐
│           Express Application            │
│              (server.js)                 │
└─────────────────────────────────────────┘
                    │
        ┌───────────┼───────────┐
        │           │           │
        ▼           ▼           ▼
┌──────────┐  ┌──────────┐  ┌──────────┐
│  Routes  │  │Middleware│  │  Config  │
└──────────┘  └──────────┘  └──────────┘
        │
        ▼
┌──────────────────────────────────────────┐
│            Controllers                    │
│  (业务逻辑协调层)                         │
└──────────────────────────────────────────┘
        │
        ▼
┌──────────────────────────────────────────┐
│             Services                      │
│  (业务逻辑实现层)                         │
└──────────────────────────────────────────┘
        │
        ▼
┌──────────────────────────────────────────┐
│          Database Layer                   │
│  (数据访问层 - db.js)                     │
└──────────────────────────────────────────┘
```

### 目录结构


```
project-root/
├── server.js                    # 主入口文件（精简版）
├── src/
│   ├── config/                  # 配置文件
│   │   ├── index.js            # 配置入口
│   │   ├── cors.js             # CORS 配置
│   │   ├── jwt.js              # JWT 配置
│   │   └── constants.js        # 常量定义
│   │
│   ├── middleware/              # 中间件
│   │   ├── auth.js             # 认证中间件
│   │   ├── errorHandler.js    # 错误处理中间件
│   │   └── requestLogger.js   # 请求日志中间件
│   │
│   ├── routes/                  # 路由定义
│   │   ├── index.js            # 路由入口（聚合所有路由）
│   │   ├── auth.routes.js      # 认证路由
│   │   ├── user.routes.js      # 用户路由
│   │   ├── bank.routes.js      # 题库路由
│   │   ├── question.routes.js  # 题目路由
│   │   ├── practice.routes.js  # 练习路由
│   │   ├── exam.routes.js      # 考试路由
│   │   ├── practical.routes.js # 实操路由
│   │   ├── discussion.routes.js# 讨论路由
│   │   ├── ai.routes.js        # AI 路由
│   │   ├── admin.routes.js     # 管理员路由
│   │   ├── tag.routes.js       # 标签路由
│   │   └── system.routes.js    # 系统路由
│   │
│   ├── controllers/             # 控制器
│   │   ├── auth.controller.js
│   │   ├── user.controller.js
│   │   ├── bank.controller.js
│   │   ├── question.controller.js
│   │   ├── practice.controller.js
│   │   ├── exam.controller.js
│   │   ├── practical.controller.js
│   │   ├── discussion.controller.js
│   │   ├── ai.controller.js
│   │   ├── admin.controller.js
│   │   ├── tag.controller.js
│   │   └── system.controller.js
│   │
│   ├── services/                # 业务服务
│   │   ├── auth.service.js
│   │   ├── user.service.js
│   │   ├── bank.service.js
│   │   ├── question.service.js
│   │   ├── practice.service.js
│   │   ├── exam.service.js
│   │   ├── practical.service.js
│   │   ├── discussion.service.js
│   │   ├── ai.service.js
│   │   ├── tag.service.js
│   │   └── srs.service.js
│   │
│   └── utils/                   # 工具函数
│       ├── parsers.js          # 数据解析工具
│       ├── validators.js       # 数据验证工具
│       └── helpers.js          # 辅助函数
│
├── db.js                        # 数据库连接（保持不变）
├── utils/                       # 现有工具（保持不变）
│   ├── logger.js
│   ├── deepseek.ts
│   └── questionValidation.js
│
└── scripts/                     # 脚本目录
    ├── sync-to-github.bat      # GitHub 同步脚本（新增）
    ├── deploy.bat              # 部署脚本（更新）
    └── quick-deploy.bat        # 快速部署脚本（更新）
```

## 组件和接口设计

### 1. 主入口文件 (server.js)

精简后的 server.js 只负责：
- 初始化 Express 应用
- 加载全局中间件
- 注册路由
- 启动服务器
- 错误处理

```javascript
// server.js (精简版示例)
import express from 'express';
import cors from 'cors';
import { corsOptions } from './src/config/cors.js';
import { requestLogger, errorLogger } from './src/middleware/requestLogger.js';
import { errorHandler } from './src/middleware/errorHandler.js';
import routes from './src/routes/index.js';
import logger from './utils/logger.js';
import db from './db.js';

const app = express();
const port = process.env.PORT || 3001;

// 全局中间件
app.use(cors(corsOptions));
app.use(express.json({ limit: '50mb' }));
app.use(requestLogger);

// 注册所有路由
app.use('/api', routes);

// 错误处理
app.use(errorLogger);
app.use(errorHandler);

// 启动服务器
app.listen(port, () => {
  logger.info('服务器启动成功', { port, database: 'PostgreSQL' });
});
```

### 2. 配置模块 (src/config/)



#### cors.js
```javascript
// 导出 CORS 配置
export const corsOptions = {
  origin: function (origin, callback) { /* ... */ },
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'PATCH', 'OPTIONS'],
  credentials: true,
  // ...
};
```

#### jwt.js
```javascript
// 导出 JWT 配置
export const JWT_SECRET = process.env.JWT_SECRET || 'edumaster-secure-2025';
export const JWT_EXPIRES_IN = '7d';
```

#### constants.js
```javascript
// 导出常量
export const ONLINE_THRESHOLD = 5 * 60 * 1000; // 5分钟
export const MAX_FILE_SIZE = 50 * 1024 * 1024; // 50MB
export const DEFAULT_PAGE_SIZE = 20;
// ...
```

### 3. 中间件模块 (src/middleware/)

#### auth.js
```javascript
import jwt from 'jsonwebtoken';
import { JWT_SECRET } from '../config/jwt.js';
import logger from '../../utils/logger.js';

export const auth = (req, res, next) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader?.split(' ')[1];
  
  if (!token) {
    logger.warn('认证失败：缺少 token', { url: req.originalUrl });
    return res.status(401).send('Unauthorized');
  }
  
  try {
    const decoded = jwt.verify(token, JWT_SECRET);
    req.user = decoded;
    next();
  } catch (err) {
    logger.warn('认证失败：token 无效', { error: err.message });
    return res.status(403).send('Forbidden');
  }
};

// 管理员权限中间件
export const adminAuth = (req, res, next) => {
  if (!req.user || req.user.role !== 'ADMIN') {
    return res.status(403).send('Forbidden');
  }
  next();
};
```

#### errorHandler.js
```javascript
import logger from '../../utils/logger.js';

export const errorHandler = (err, req, res, next) => {
  logger.error('服务器错误', { 
    error: err.message, 
    stack: err.stack,
    url: req.originalUrl 
  });
  
  res.status(500).json({ 
    error: '服务器内部错误', 
    code: 'INTERNAL_SERVER_ERROR',
    details: process.env.NODE_ENV === 'development' ? err.message : undefined
  });
};
```

### 4. 路由模块 (src/routes/)

#### index.js (路由聚合器)
```javascript
import express from 'express';
import authRoutes from './auth.routes.js';
import userRoutes from './user.routes.js';
import bankRoutes from './bank.routes.js';
// ... 其他路由

const router = express.Router();

// 注册所有路由
router.use('/auth', authRoutes);
router.use('/user', userRoutes);
router.use('/banks', bankRoutes);
// ... 其他路由

export default router;
```

#### auth.routes.js (示例)
```javascript
import express from 'express';
import * as authController from '../controllers/auth.controller.js';

const router = express.Router();

router.post('/login', authController.login);
router.post('/change-password', authController.changePassword);
router.post('/heartbeat', authController.heartbeat);

export default router;
```

### 5. 控制器模块 (src/controllers/)

控制器负责：
- 接收和验证请求参数
- 调用服务层处理业务逻辑
- 格式化响应数据
- 处理错误

#### auth.controller.js (示例)
```javascript
import * as authService from '../services/auth.service.js';
import logger from '../../utils/logger.js';

export const login = async (req, res) => {
  try {
    const { phone, password, role } = req.body;
    
    const result = await authService.login(phone, password, role, req.ip);
    
    if (result.success) {
      res.json({ token: result.token, user: result.user });
    } else {
      res.status(401).send('账号或密码错误');
    }
  } catch (error) {
    logger.error('登录失败', { error: error.message });
    res.status(500).send('登录失败');
  }
};

export const changePassword = async (req, res) => {
  try {
    const { old, newP } = req.body;
    const userId = req.user.id;
    
    const result = await authService.changePassword(userId, old, newP);
    
    if (result.success) {
      res.json({ success: true, message: '密码修改成功' });
    } else {
      res.status(401).json({ error: result.error });
    }
  } catch (error) {
    logger.error('修改密码失败', { error: error.message });
    res.status(500).send(error.message);
  }
};

export const heartbeat = async (req, res) => {
  try {
    const lastActivity = await authService.updateLastActivity(req.user.id);
    res.json({ success: true, lastActivity });
  } catch (error) {
    logger.error('心跳更新失败', { error: error.message });
    res.status(500).send(error.message);
  }
};
```

### 6. 服务模块 (src/services/)

服务层负责：
- 实现核心业务逻辑
- 数据库操作
- 数据转换和验证
- 业务规则执行



#### auth.service.js (示例)
```javascript
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import db from '../../db.js';
import { JWT_SECRET, JWT_EXPIRES_IN } from '../config/jwt.js';
import logger from '../../utils/logger.js';

export const login = async (phone, password, role, ip) => {
  // 查询用户
  const user = await db.getOne(
    'SELECT * FROM users WHERE phone = $1 AND role = $2',
    [phone, role]
  );
  
  if (!user || !bcrypt.compareSync(password, user.password)) {
    return { success: false };
  }
  
  // 更新登录信息
  const now = new Date().toISOString();
  const loginHistory = user.login_history || [];
  loginHistory.push(now);
  if (loginHistory.length > 100) {
    loginHistory.splice(0, loginHistory.length - 100);
  }
  
  await db.execute(
    'UPDATE users SET last_login = $1, login_history = $2, last_activity = $3 WHERE id = $4',
    [now, JSON.stringify(loginHistory), now, user.id]
  );
  
  // 记录登录日志
  const logId = `log-${Date.now()}-${Math.random().toString(36).slice(2, 9)}`;
  await db.execute(
    'INSERT INTO login_logs (id, user_id, phone, role, time, ip) VALUES ($1, $2, $3, $4, $5, $6)',
    [logId, user.id, phone, role, now, ip]
  );
  
  // 生成 token
  const token = jwt.sign({ id: user.id, role: user.role }, JWT_SECRET, { 
    expiresIn: JWT_EXPIRES_IN 
  });
  
  // 移除密码字段
  const { password: _, ...safeUser } = user;
  
  return { 
    success: true, 
    token, 
    user: transformUserFields(safeUser) 
  };
};

export const changePassword = async (userId, oldPassword, newPassword) => {
  // 验证参数
  if (!oldPassword || !newPassword) {
    return { success: false, error: '请提供旧密码和新密码' };
  }
  
  if (newPassword.length < 4) {
    return { success: false, error: '新密码长度至少为4位' };
  }
  
  // 获取用户
  const user = await db.getOne('SELECT * FROM users WHERE id = $1', [userId]);
  
  if (!user) {
    return { success: false, error: '用户不存在' };
  }
  
  // 验证旧密码
  if (!bcrypt.compareSync(oldPassword, user.password)) {
    return { success: false, error: '旧密码不正确' };
  }
  
  // 更新密码
  const newHash = bcrypt.hashSync(newPassword, 10);
  await db.execute('UPDATE users SET password = $1 WHERE id = $2', [newHash, userId]);
  
  logger.info('密码修改成功', { userId });
  return { success: true };
};

export const updateLastActivity = async (userId) => {
  const lastActivity = new Date().toISOString();
  await db.execute('UPDATE users SET last_activity = $1 WHERE id = $2', [lastActivity, userId]);
  return lastActivity;
};

// 辅助函数：转换字段名为 camelCase
function transformUserFields(user) {
  return {
    ...user,
    realName: user.real_name,
    idCard: user.id_card,
    educationType: user.education_type,
    educationLevel: user.education_level,
    className: user.class_name,
    studentPerms: user.student_perms || [],
    allowedBankIds: user.allowed_bank_ids || [],
    lastLogin: user.last_login,
    lastActivity: user.last_activity,
    loginHistory: user.login_history || [],
    deepseekApiKey: user.deepseek_api_key,
    totalOnlineTime: user.total_online_time || 0,
    customFields: user.custom_fields || {},
    mistakeCount: user.mistake_count || 0,
    dailyGoal: user.daily_goal || 20
  };
}
```

### 7. 工具模块 (src/utils/)

#### parsers.js
```javascript
// 解析选项字段（兼容旧格式）
export const parseOptionsField = (val) => {
  if (!val) return [];
  if (Array.isArray(val)) return val;
  if (typeof val === 'string') {
    try { 
      const parsed = JSON.parse(val); 
      return Array.isArray(parsed) ? parsed : []; 
    } catch (e) {
      return val.includes('|') ? val.split('|') : [val];
    }
  }
  return [];
};

// 解析答案字段
export const parseAnswerField = (val) => {
  if (val === undefined || val === null) return '';
  if (typeof val === 'object') return val;
  if (typeof val === 'string') {
    try { return JSON.parse(val); } catch (e) { return val; }
  }
  return val;
};

// 规范化数组字段
export const normalizeArrayField = (v) => {
  if (!v) return [];
  if (Array.isArray(v)) return v;
  if (typeof v === 'string') {
    try {
      const p = JSON.parse(v);
      if (Array.isArray(p)) return p;
      if (typeof p === 'string') {
        try {
          const q = JSON.parse(p);
          if (Array.isArray(q)) return q;
        } catch (e) {}
      }
    } catch (e) {}
    const match = v.match(/bank-[0-9]+/g);
    if (match) return match;
    return [];
  }
  return [];
};
```

#### validators.js
```javascript
// 验证填空题答案
export const validateFillInBlankAnswers = (blanks, userAnswers, totalScore) => {
  // 从现有的 utils/questionValidation.js 迁移
  // ...
};

// 验证邮箱格式
export const isValidEmail = (email) => {
  const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return re.test(email);
};

// 验证手机号格式
export const isValidPhone = (phone) => {
  const re = /^1[3-9]\d{9}$/;
  return re.test(phone);
};
```

## 数据模型

数据模型保持不变，继续使用 PostgreSQL 数据库和现有的表结构。所有数据访问通过 `db.js` 模块进行。

### 字段命名转换

数据库使用 snake_case 命名（如 `user_id`, `last_login`），API 响应使用 camelCase 命名（如 `userId`, `lastLogin`）。

转换规则：
- 数据库 → API: snake_case → camelCase
- API → 数据库: camelCase → snake_case

转换在服务层完成，确保控制器和路由层使用统一的 camelCase 命名。



## 正确性属性

*属性是系统应该满足的特征或行为，它应该在所有有效执行中保持为真。属性是人类可读规范和机器可验证正确性保证之间的桥梁。*

基于需求分析，以下是可测试的正确性属性：

### 属性 1: API 端点保持不变
*对于任何* 现有的 API 端点，重构后该端点应该仍然可访问且返回相同格式的响应
**验证需求: 6.1, 6.2**

### 属性 2: 认证机制保持一致
*对于任何* 需要认证的 API 请求，使用相同的 token 应该得到相同的认证结果
**验证需求: 6.2**

### 属性 3: 数据库操作结果一致
*对于任何* 数据库操作（增删改查），重构前后应该产生相同的结果
**验证需求: 6.3**

### 属性 4: 部署脚本执行完整性
*对于任何* 成功的部署，脚本应该完成所有必需的步骤（备份、拉取、安装、重启、验证）
**验证需求: 2.1**

### 属性 5: 部署失败回滚
*对于任何* 部署失败的情况，系统应该自动回滚到上一个稳定版本
**验证需求: 2.2**

### 属性 6: Git 同步操作完整性
*对于任何* Git 同步操作，脚本应该按顺序执行所有 Git 命令（status, add, commit, push）
**验证需求: 3.2**

### 属性 7: 环境变量验证
*对于任何* 部署操作，脚本应该验证所有必需的环境变量都已配置
**验证需求: 2.5**

### 属性 8: 性能不降级
*对于任何* API 端点，重构后的响应时间不应该超过重构前的 110%
**验证需求: 7.1**

### 属性 9: 中间件执行顺序
*对于任何* HTTP 请求，中间件的执行顺序应该与重构前保持一致
**验证需求: 7.3**

### 属性 10: 测试覆盖率保持
*对于任何* 新创建的模块，测试覆盖率应该不低于 70%
**验证需求: 8.5**

## 错误处理

### 错误处理策略

1. **统一错误格式**
   ```javascript
   {
     error: '错误描述',
     code: 'ERROR_CODE',
     details: '详细信息（仅开发环境）'
   }
   ```

2. **错误分类**
   - 客户端错误 (4xx): 参数错误、认证失败、权限不足等
   - 服务器错误 (5xx): 数据库错误、外部服务错误等

3. **错误日志**
   - 所有错误都应该记录到日志系统
   - 包含错误堆栈、请求信息、用户信息等上下文

4. **错误恢复**
   - 数据库连接失败：自动重试
   - 外部 API 调用失败：降级处理
   - 文件操作失败：清理临时文件

### 错误处理实现

```javascript
// src/middleware/errorHandler.js
export const errorHandler = (err, req, res, next) => {
  // 记录错误
  logger.error('服务器错误', { 
    error: err.message, 
    stack: err.stack,
    url: req.originalUrl,
    method: req.method,
    user: req.user?.id
  });
  
  // 根据错误类型返回不同的状态码
  let statusCode = 500;
  let errorCode = 'INTERNAL_SERVER_ERROR';
  
  if (err.name === 'ValidationError') {
    statusCode = 400;
    errorCode = 'VALIDATION_ERROR';
  } else if (err.name === 'UnauthorizedError') {
    statusCode = 401;
    errorCode = 'UNAUTHORIZED';
  } else if (err.name === 'ForbiddenError') {
    statusCode = 403;
    errorCode = 'FORBIDDEN';
  } else if (err.name === 'NotFoundError') {
    statusCode = 404;
    errorCode = 'NOT_FOUND';
  }
  
  res.status(statusCode).json({ 
    error: err.message || '服务器内部错误', 
    code: errorCode,
    details: process.env.NODE_ENV === 'development' ? err.stack : undefined
  });
};
```

## 测试策略

### 测试层次

1. **单元测试**
   - 测试目标：服务层、工具函数
   - 测试框架：Vitest
   - 覆盖率目标：≥ 80%
   - 测试内容：
     - 业务逻辑函数
     - 数据转换函数
     - 验证函数

2. **集成测试**
   - 测试目标：API 端点、数据库操作
   - 测试框架：Vitest + Supertest
   - 覆盖率目标：≥ 70%
   - 测试内容：
     - API 端点响应
     - 数据库 CRUD 操作
     - 认证和授权流程

3. **端到端测试**
   - 测试目标：完整业务流程
   - 测试框架：Playwright（可选）
   - 测试内容：
     - 用户登录流程
     - 题目练习流程
     - 考试流程

### 测试组织

```
tests/
├── unit/                    # 单元测试
│   ├── services/
│   │   ├── auth.service.test.js
│   │   ├── user.service.test.js
│   │   └── ...
│   └── utils/
│       ├── parsers.test.js
│       └── validators.test.js
│
├── integration/             # 集成测试
│   ├── auth.test.js
│   ├── user.test.js
│   ├── bank.test.js
│   └── ...
│
└── e2e/                     # 端到端测试（可选）
    ├── login.test.js
    └── practice.test.js
```

### 测试示例

#### 单元测试示例
```javascript
// tests/unit/services/auth.service.test.js
import { describe, it, expect, beforeEach, vi } from 'vitest';
import * as authService from '../../../src/services/auth.service.js';
import db from '../../../db.js';

vi.mock('../../../db.js');

describe('Auth Service', () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });
  
  describe('login', () => {
    it('应该在凭证正确时返回 token 和用户信息', async () => {
      // 模拟数据库返回
      db.getOne.mockResolvedValue({
        id: 'user-1',
        phone: '13800138000',
        password: '$2a$10$...', // bcrypt hash
        role: 'STUDENT'
      });
      
      const result = await authService.login('13800138000', 'password123', 'STUDENT', '127.0.0.1');
      
      expect(result.success).toBe(true);
      expect(result.token).toBeDefined();
      expect(result.user).toBeDefined();
      expect(result.user.phone).toBe('13800138000');
    });
    
    it('应该在凭证错误时返回失败', async () => {
      db.getOne.mockResolvedValue(null);
      
      const result = await authService.login('13800138000', 'wrongpassword', 'STUDENT', '127.0.0.1');
      
      expect(result.success).toBe(false);
    });
  });
});
```

#### 集成测试示例
```javascript
// tests/integration/auth.test.js
import { describe, it, expect, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import app from '../../server.js';

describe('Auth API', () => {
  describe('POST /api/auth/login', () => {
    it('应该在凭证正确时返回 200 和 token', async () => {
      const response = await request(app)
        .post('/api/auth/login')
        .send({
          phone: '13800138000',
          password: 'password123',
          role: 'STUDENT'
        });
      
      expect(response.status).toBe(200);
      expect(response.body.token).toBeDefined();
      expect(response.body.user).toBeDefined();
    });
    
    it('应该在凭证错误时返回 401', async () => {
      const response = await request(app)
        .post('/api/auth/login')
        .send({
          phone: '13800138000',
          password: 'wrongpassword',
          role: 'STUDENT'
        });
      
      expect(response.status).toBe(401);
    });
  });
});
```



## 部署脚本设计

### 1. GitHub 同步脚本 (sync-to-github.bat)

```batch
@echo off
chcp 65001 >nul
echo ========================================
echo   GitHub 代码同步脚本
echo ========================================
echo.

REM 检查 Git 状态
echo [1/5] 检查 Git 状态...
git status
if %errorlevel% neq 0 (
    echo 错误: Git 状态检查失败
    pause
    exit /b 1
)
echo.

REM 显示未提交的更改
echo [2/5] 显示未提交的更改...
git status --short
echo.

REM 询问是否继续
set /p CONTINUE="是否继续提交并推送? (y/n): "
if /i not "%CONTINUE%"=="y" (
    echo 操作已取消
    pause
    exit /b 0
)
echo.

REM 添加所有更改
echo [3/5] 添加所有更改...
git add .
if %errorlevel% neq 0 (
    echo 错误: 添加文件失败
    pause
    exit /b 1
)
echo.

REM 输入提交信息
echo [4/5] 输入提交信息...
set /p COMMIT_MSG="请输入提交信息: "
if "%COMMIT_MSG%"=="" (
    set COMMIT_MSG=更新代码
)
git commit -m "%COMMIT_MSG%"
if %errorlevel% neq 0 (
    echo 警告: 可能没有需要提交的更改
)
echo.

REM 推送到远程仓库
echo [5/5] 推送到远程仓库...
git push
if %errorlevel% neq 0 (
    echo 错误: 推送失败，请检查网络连接和权限
    pause
    exit /b 1
)
echo.

echo ========================================
echo   同步完成！
echo ========================================
pause
```

### 2. 快速部署脚本 (quick-deploy.bat) - 更新版

```batch
@echo off
chcp 65001 >nul
echo ========================================
echo   快速部署脚本 (模块化版本)
echo ========================================
echo.

REM 设置服务器信息
set SERVER_USER=root
set SERVER_HOST=your-server-ip
set SERVER_PATH=/root/edumaster
set BACKUP_DIR=/root/edumaster-backups

echo [1/6] 连接到服务器...
ssh %SERVER_USER%@%SERVER_HOST% "echo '连接成功'"
if %errorlevel% neq 0 (
    echo 错误: 无法连接到服务器
    pause
    exit /b 1
)
echo.

echo [2/6] 备份当前代码...
ssh %SERVER_USER%@%SERVER_HOST% "mkdir -p %BACKUP_DIR% && cp -r %SERVER_PATH% %BACKUP_DIR%/backup-$(date +%%Y%%m%%d-%%H%%M%%S)"
if %errorlevel% neq 0 (
    echo 警告: 备份失败，但继续部署
)
echo.

echo [3/6] 拉取最新代码...
ssh %SERVER_USER%@%SERVER_HOST% "cd %SERVER_PATH% && git pull"
if %errorlevel% neq 0 (
    echo 错误: 拉取代码失败
    pause
    exit /b 1
)
echo.

echo [4/6] 安装依赖...
ssh %SERVER_USER%@%SERVER_HOST% "cd %SERVER_PATH% && npm install --production"
if %errorlevel% neq 0 (
    echo 错误: 安装依赖失败
    pause
    exit /b 1
)
echo.

echo [5/6] 重启服务...
ssh %SERVER_USER%@%SERVER_HOST% "cd %SERVER_PATH% && pm2 restart ecosystem.config.cjs"
if %errorlevel% neq 0 (
    echo 错误: 重启服务失败，尝试回滚...
    ssh %SERVER_USER%@%SERVER_HOST% "cd %BACKUP_DIR% && ls -t | head -1 | xargs -I {} cp -r {}/edumaster/* %SERVER_PATH%/ && cd %SERVER_PATH% && pm2 restart ecosystem.config.cjs"
    pause
    exit /b 1
)
echo.

echo [6/6] 验证服务状态...
timeout /t 5 /nobreak >nul
ssh %SERVER_USER%@%SERVER_HOST% "pm2 status"
echo.

echo ========================================
echo   部署完成！
echo ========================================
pause
```

### 3. 完整部署脚本 (deploy.bat) - 更新版

在 quick-deploy.bat 的基础上增加：
- 环境变量验证
- 数据库迁移检查
- 健康检查
- 详细日志输出

```batch
@echo off
chcp 65001 >nul
echo ========================================
echo   完整部署脚本 (模块化版本)
echo ========================================
echo.

REM ... (前面步骤与 quick-deploy.bat 相同)

echo [7/9] 验证环境变量...
ssh %SERVER_USER%@%SERVER_HOST% "cd %SERVER_PATH% && node -e \"require('dotenv').config(); const required = ['DB_HOST', 'DB_USER', 'DB_PASSWORD', 'DB_NAME', 'JWT_SECRET']; const missing = required.filter(k => !process.env[k]); if (missing.length > 0) { console.error('缺少环境变量:', missing.join(', ')); process.exit(1); }\""
if %errorlevel% neq 0 (
    echo 错误: 环境变量验证失败
    pause
    exit /b 1
)
echo.

echo [8/9] 健康检查...
timeout /t 10 /nobreak >nul
curl -f http://%SERVER_HOST%:3001/api/health
if %errorlevel% neq 0 (
    echo 错误: 健康检查失败
    pause
    exit /b 1
)
echo.

echo [9/9] 查看服务日志...
ssh %SERVER_USER%@%SERVER_HOST% "cd %SERVER_PATH% && pm2 logs --lines 20"
echo.

echo ========================================
echo   部署完成并验证成功！
echo ========================================
pause
```

## 文档整理设计

### 1. docs/ 目录结构（常用文档）

```
docs/
├── README.md                    # 文档索引
├── 快速启动指南.md              # 快速开始
├── 完整部署指南.md              # 详细部署步骤
├── 登录说明.md                  # 用户登录指南
├── 管理员账号说明.md            # 管理员使用指南
└── 题库导入说明.md              # 题库导入教程
```

### 2. 备忘文件/ 目录结构（技术文档）

```
备忘文件/
├── README.md                    # 技术文档索引
├── 架构设计/
│   ├── 系统架构说明.md
│   ├── 数据库设计.md
│   └── API设计.md
├── 部署运维/
│   ├── Docker部署指南.md
│   ├── Nginx配置说明.md
│   ├── SSL证书配置指南.md
│   └── 服务器准备指南.md
├── 开发指南/
│   ├── 开发环境搭建.md
│   ├── 代码规范.md
│   └── Git工作流.md
├── 安全配置/
│   ├── CORS安全配置指南.md
│   ├── 数据库安全配置.md
│   └── 密码管理.md
└── CI_CD/
    ├── CI_CD_SETUP.md
    └── CICD_QUICK_REFERENCE.md
```

### 3. 主 README.md 更新

在主 README.md 中添加文档导航：

```markdown
## 📚 文档导航

### 快速开始
- [快速启动指南](docs/快速启动指南.md) - 5分钟快速部署
- [登录说明](docs/登录说明.md) - 用户登录指南
- [管理员说明](docs/管理员账号说明.md) - 管理员功能说明

### 部署文档
- [完整部署指南](docs/完整部署指南.md) - 详细部署步骤
- [题库导入说明](docs/题库导入说明.md) - 题库数据导入

### 技术文档
详细的技术文档请查看 [备忘文件/README.md](备忘文件/README.md)

### 开发文档
- [架构设计](备忘文件/架构设计/) - 系统架构和设计文档
- [开发指南](备忘文件/开发指南/) - 开发环境和代码规范
- [API文档](备忘文件/架构设计/API设计.md) - API接口文档
```

## 迁移策略

### 迁移步骤

1. **准备阶段**
   - 创建新的目录结构
   - 设置测试环境
   - 准备回滚方案

2. **模块提取阶段**（按功能域逐步迁移）
   - 第一批：配置和中间件（低风险）
   - 第二批：认证和用户模块（中风险）
   - 第三批：题库和题目模块（中风险）
   - 第四批：练习和考试模块（高风险）
   - 第五批：其他模块（低风险）

3. **测试阶段**
   - 单元测试
   - 集成测试
   - 性能测试
   - 兼容性测试

4. **部署阶段**
   - 在测试环境验证
   - 在预生产环境验证
   - 生产环境灰度发布
   - 全量发布

5. **清理阶段**
   - 删除旧代码
   - 更新文档
   - 归档备份

### 风险控制

1. **代码审查**: 所有重构代码必须经过审查
2. **自动化测试**: 每次提交都运行测试套件
3. **灰度发布**: 逐步切换流量到新版本
4. **监控告警**: 实时监控系统指标
5. **快速回滚**: 保持回滚能力，出现问题立即回滚

## 性能优化

### 优化策略

1. **懒加载**: 模块按需加载，减少启动时间
2. **缓存**: 合理使用缓存减少数据库查询
3. **连接池**: 优化数据库连接池配置
4. **异步处理**: 使用异步操作提高并发能力
5. **代码分割**: 避免单个文件过大

### 性能监控

- 使用 `logger` 记录关键操作的耗时
- 使用 `/api/monitor/database` 端点监控数据库性能
- 使用 PM2 监控进程状态和资源使用

## 总结

本设计文档描述了将 4100+ 行的 server.js 文件重构为模块化架构的完整方案。重构将采用分层架构，按功能域组织代码，同时保持向后兼容性和系统性能。通过完善的测试策略和迁移计划，确保重构过程的安全性和可控性。
