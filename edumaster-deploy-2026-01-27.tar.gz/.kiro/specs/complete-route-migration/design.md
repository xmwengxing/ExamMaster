# 设计文档：完整路由迁移

## 概述

本设计文档描述了如何系统地补充后端模块化重构中遗漏的路由。我们将按照现有的模块化架构模式，为每个功能模块创建 service 层、controller 层和 routes 层，并确保与原 server.js 实现完全兼容。

### 设计目标

1. **完整性**：补充所有遗漏的路由，确保前端功能正常
2. **一致性**：遵循现有的模块化架构模式
3. **兼容性**：保持与原 server.js 实现的 API 兼容
4. **可测试性**：为所有新代码编写单元测试和集成测试
5. **可维护性**：清晰的代码结构和文档

### 技术栈

- **语言**：JavaScript (Node.js)
- **框架**：Express.js
- **数据库**：PostgreSQL
- **测试框架**：Vitest
- **认证**：JWT

## 架构

### 分层架构

```
┌─────────────────────────────────────┐
│         Routes Layer                │  ← HTTP 路由定义
│  (src/routes/*.routes.js)           │
└──────────────┬──────────────────────┘
               │
┌──────────────▼──────────────────────┐
│       Controller Layer              │  ← 请求处理和响应
│  (src/controllers/*.controller.js)  │
└──────────────┬──────────────────────┘
               │
┌──────────────▼──────────────────────┐
│        Service Layer                │  ← 业务逻辑
│  (src/services/*.service.js)        │
└──────────────┬──────────────────────┘
               │
┌──────────────▼──────────────────────┐
│       Database Layer                │  ← 数据访问
│  (req.db - PostgreSQL)              │
└─────────────────────────────────────┘
```

### 模块划分

根据功能领域，我们将新增或扩展以下模块：

1. **Mistake Module** (错题管理) - 新增
2. **Favorite Module** (收藏管理) - 新增
3. **Note Module** (笔记管理) - 新增
4. **SRS Module** (间隔重复系统) - 扩展现有
5. **Admin Module** (管理员管理) - 扩展现有
6. **Log Module** (日志管理) - 新增

## 组件和接口

### 1. Mistake Module（错题管理）

#### Service Layer: `src/services/mistake.service.js`

```javascript
/**
 * 获取用户的错题列表
 * @param {Object} db - 数据库连接
 * @param {string} userId - 用户ID
 * @returns {Promise<Array>} 错题列表（包含完整题目信息）
 */
async function getUserMistakes(db, userId)

/**
 * 添加错题
 * @param {Object} db - 数据库连接
 * @param {string} userId - 用户ID
 * @param {string} questionId - 题目ID
 * @returns {Promise<Object>} { success: boolean, added: boolean }
 */
async function addMistake(db, userId, questionId)
```

#### Controller Layer: `src/controllers/mistake.controller.js`

```javascript
/**
 * GET /api/mistakes
 * 获取当前用户的错题列表
 */
async function getMistakes(req, res)

/**
 * POST /api/mistakes
 * 添加错题到错题集
 */
async function addMistake(req, res)
```

#### Routes Layer: `src/routes/mistake.routes.js`

```javascript
router.get('/', auth, getMistakes);
router.post('/', auth, addMistake);
```

### 2. Favorite Module（收藏管理）

#### Service Layer: `src/services/favorite.service.js`

```javascript
/**
 * 获取用户的收藏列表
 * @param {Object} db - 数据库连接
 * @param {string} userId - 用户ID
 * @returns {Promise<Array>} 收藏列表（包含完整题目信息）
 */
async function getUserFavorites(db, userId)

/**
 * 切换收藏状态（收藏/取消收藏）
 * @param {Object} db - 数据库连接
 * @param {string} userId - 用户ID
 * @param {string} questionId - 题目ID
 * @returns {Promise<Object>} { success: boolean, favorited: boolean }
 */
async function toggleFavorite(db, userId, questionId)
```

#### Controller Layer: `src/controllers/favorite.controller.js`

```javascript
/**
 * GET /api/favorites
 * 获取当前用户的收藏列表
 */
async function getFavorites(req, res)

/**
 * POST /api/favorites/:qId
 * 切换题目的收藏状态
 */
async function toggleFavorite(req, res)
```

#### Routes Layer: `src/routes/favorite.routes.js`

```javascript
router.get('/', auth, getFavorites);
router.post('/:qId', auth, toggleFavorite);
```

### 3. Note Module（笔记管理）

#### Service Layer: `src/services/note.service.js`

```javascript
/**
 * 保存或更新笔记
 * @param {Object} db - 数据库连接
 * @param {string} userId - 用户ID
 * @param {string} questionId - 题目ID
 * @param {string} content - 笔记内容
 * @returns {Promise<Object>} { success: boolean, deleted?: boolean }
 */
async function saveNote(db, userId, questionId, content)

/**
 * 获取笔记
 * @param {Object} db - 数据库连接
 * @param {string} userId - 用户ID
 * @param {string} questionId - 题目ID
 * @returns {Promise<Object|null>} 笔记对象或 null
 */
async function getNote(db, userId, questionId)
```

#### Controller Layer: `src/controllers/note.controller.js`

```javascript
/**
 * POST /api/notes
 * 保存或删除笔记（内容为空时删除）
 */
async function saveNote(req, res)

/**
 * GET /api/notes/:qId
 * 获取指定题目的笔记
 */
async function getNote(req, res)
```

#### Routes Layer: `src/routes/note.routes.js`

```javascript
router.post('/', auth, saveNote);
router.get('/:qId', auth, getNote);
```

### 4. SRS Module（间隔重复系统）- 扩展

#### Service Layer: `src/services/srs.service.js` - 新增函数

```javascript
/**
 * 获取用户的 SRS 记录
 * @param {Object} db - 数据库连接
 * @param {string} userId - 用户ID
 * @returns {Promise<Array>} SRS 记录列表
 */
async function getSRSRecords(db, userId)
```

#### Controller Layer: `src/controllers/srs.controller.js` - 新增

```javascript
/**
 * GET /api/srs/records
 * 获取当前用户的 SRS 记录
 */
async function getSRSRecords(req, res)
```

#### Routes Layer: 更新现有路由文件或创建新文件

### 5. Admin Module（管理员管理）- 扩展

#### Service Layer: `src/services/admin.service.js` - 新增函数

```javascript
/**
 * 获取所有管理员列表
 * @param {Object} db - 数据库连接
 * @returns {Promise<Array>} 管理员列表
 */
async function getAllAdmins(db)

/**
 * 创建管理员账号
 * @param {Object} db - 数据库连接
 * @param {Object} adminData - 管理员数据
 * @returns {Promise<Object>} { success: boolean, id: string }
 */
async function createAdmin(db, adminData)

/**
 * 更新管理员信息
 * @param {Object} db - 数据库连接
 * @param {string} adminId - 管理员ID
 * @param {Object} updates - 更新数据
 * @returns {Promise<Object>} { success: boolean }
 */
async function updateAdmin(db, adminId, updates)

/**
 * 删除管理员账号
 * @param {Object} db - 数据库连接
 * @param {string} adminId - 管理员ID
 * @returns {Promise<Object>} { success: boolean }
 */
async function deleteAdmin(db, adminId)

/**
 * 修改管理员密码
 * @param {Object} db - 数据库连接
 * @param {string} adminId - 管理员ID
 * @param {string} oldPassword - 旧密码
 * @param {string} newPassword - 新密码
 * @returns {Promise<Object>} { success: boolean }
 */
async function changeAdminPassword(db, adminId, oldPassword, newPassword)

/**
 * 获取所有考试历史
 * @param {Object} db - 数据库连接
 * @returns {Promise<Array>} 考试历史列表
 */
async function getAllExamHistory(db)

/**
 * 获取所有学员进度
 * @param {Object} db - 数据库连接
 * @returns {Promise<Array>} 进度列表
 */
async function getAllProgress(db)

/**
 * 修复学生权限字段（幂等操作）
 * @param {Object} db - 数据库连接
 * @returns {Promise<Object>} { success: boolean, fixed: number }
 */
async function repairStudentSchema(db)
```

#### Controller Layer: `src/controllers/admin.controller.js` - 新增函数

```javascript
/**
 * GET /api/admin/admins
 * 获取所有管理员列表
 */
async function getAdmins(req, res)

/**
 * POST /api/admin/admins
 * 创建管理员账号
 */
async function createAdmin(req, res)

/**
 * PUT /api/admin/admins/:id
 * 更新管理员信息
 */
async function updateAdmin(req, res)

/**
 * DELETE /api/admin/admins/:id
 * 删除管理员账号
 */
async function deleteAdmin(req, res)

/**
 * POST /api/admin/change-password
 * 修改管理员密码
 */
async function changePassword(req, res)

/**
 * GET /api/admin/exam-history
 * 获取所有考试历史
 */
async function getExamHistory(req, res)

/**
 * GET /api/admin/all-progress
 * 获取所有学员进度
 */
async function getAllProgress(req, res)

/**
 * POST /api/admin/repair-student-schema
 * 修复学生权限字段
 */
async function repairStudentSchema(req, res)
```

#### Routes Layer: `src/routes/admin.routes.js` - 新增路由

```javascript
// 管理员账号管理
router.get('/admins', adminAuth, getAdmins);
router.post('/admins', adminAuth, createAdmin);
router.put('/admins/:id', adminAuth, updateAdmin);
router.delete('/admins/:id', adminAuth, deleteAdmin);
router.post('/change-password', adminAuth, changePassword);

// 考试历史和进度
router.get('/exam-history', adminAuth, getExamHistory);
router.get('/all-progress', adminAuth, getAllProgress);

// 数据库修复
router.post('/repair-student-schema', adminAuth, repairStudentSchema);
```

### 6. Log Module（日志管理）- 新增

#### Service Layer: `src/services/log.service.js`

```javascript
/**
 * 获取登录日志
 * @param {Object} db - 数据库连接
 * @returns {Promise<Array>} 登录日志列表
 */
async function getLoginLogs(db)

/**
 * 获取审计日志
 * @param {Object} db - 数据库连接
 * @returns {Promise<Array>} 审计日志列表
 */
async function getAuditLogs(db)

/**
 * 创建审计日志
 * @param {Object} db - 数据库连接
 * @param {Object} logData - 日志数据
 * @returns {Promise<Object>} { success: boolean }
 */
async function createAuditLog(db, logData)
```

#### Controller Layer: `src/controllers/log.controller.js`

```javascript
/**
 * GET /api/admin/login-logs
 * 获取登录日志
 */
async function getLoginLogs(req, res)

/**
 * GET /api/admin/audit-logs
 * 获取审计日志
 */
async function getAuditLogs(req, res)

/**
 * POST /api/admin/audit-logs
 * 创建审计日志
 */
async function createAuditLog(req, res)
```

#### Routes Layer: `src/routes/log.routes.js`

```javascript
router.get('/login-logs', adminAuth, getLoginLogs);
router.get('/audit-logs', adminAuth, getAuditLogs);
router.post('/audit-logs', adminAuth, createAuditLog);
```

## 数据模型

### Mistakes Table（错题表）

```sql
CREATE TABLE mistakes (
  user_id TEXT NOT NULL,
  question_id TEXT NOT NULL,
  PRIMARY KEY (user_id, question_id),
  FOREIGN KEY (user_id) REFERENCES users(id),
  FOREIGN KEY (question_id) REFERENCES questions(id)
);
```

### Favorites Table（收藏表）

```sql
CREATE TABLE favorites (
  user_id TEXT NOT NULL,
  question_id TEXT NOT NULL,
  PRIMARY KEY (user_id, question_id),
  FOREIGN KEY (user_id) REFERENCES users(id),
  FOREIGN KEY (question_id) REFERENCES questions(id)
);
```

### Notes Table（笔记表）

```sql
CREATE TABLE notes (
  user_id TEXT NOT NULL,
  question_id TEXT NOT NULL,
  content TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  PRIMARY KEY (user_id, question_id),
  FOREIGN KEY (user_id) REFERENCES users(id),
  FOREIGN KEY (question_id) REFERENCES questions(id)
);
```

### SRS Records Table（SRS 记录表）

```sql
CREATE TABLE srs_records (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL,
  question_id TEXT NOT NULL,
  interval INTEGER NOT NULL,
  ease_factor REAL NOT NULL,
  repetitions INTEGER NOT NULL,
  next_review_date TEXT NOT NULL,
  status TEXT NOT NULL,
  UNIQUE (user_id, question_id),
  FOREIGN KEY (user_id) REFERENCES users(id),
  FOREIGN KEY (question_id) REFERENCES questions(id)
);
```

### Login Logs Table（登录日志表）

```sql
CREATE TABLE login_logs (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL,
  role TEXT NOT NULL,
  ip TEXT,
  user_agent TEXT,
  timestamp TEXT NOT NULL,
  FOREIGN KEY (user_id) REFERENCES users(id)
);
```

### Audit Logs Table（审计日志表）

```sql
CREATE TABLE audit_logs (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL,
  action TEXT NOT NULL,
  details TEXT,
  timestamp TEXT NOT NULL,
  FOREIGN KEY (user_id) REFERENCES users(id)
);
```

### Daily Progress Table（每日进度表）

```sql
CREATE TABLE daily_progress (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL,
  date TEXT NOT NULL,
  count INTEGER NOT NULL DEFAULT 0,
  FOREIGN KEY (user_id) REFERENCES users(id)
);
```

## 正确性属性

*属性是一个特征或行为，应该在系统的所有有效执行中保持为真——本质上是关于系统应该做什么的形式化陈述。属性作为人类可读规范和机器可验证正确性保证之间的桥梁。*


### 属性 1：用户数据隔离

*对于任何*学员用户，当查询个人数据（错题、收藏、SRS 记录、笔记）时，返回的结果应该只包含该用户自己的数据，不包含其他用户的数据。

**验证：需求 5.1, 6.1, 7.1**

### 属性 2：添加操作的持久化

*对于任何*有效的添加操作（添加错题、添加收藏、保存笔记），执行后立即查询应该能够获取到刚添加的数据。

**验证：需求 6.2, 7.2, 8.1**

### 属性 3：删除操作的完整性

*对于任何*有效的删除操作（删除管理员、删除收藏、删除笔记），执行后立即查询应该无法获取到已删除的数据。

**验证：需求 1.4, 7.3**

### 属性 4：收藏切换的往返一致性

*对于任何*题目，连续执行两次收藏操作后，收藏状态应该回到初始状态（未收藏 → 收藏 → 未收藏，或 收藏 → 未收藏 → 收藏）。

**验证：需求 7.4**

### 属性 5：错题添加的幂等性

*对于任何*题目，多次添加到错题集的操作应该只产生一条记录，不会重复添加。

**验证：需求 6.3**

### 属性 6：数据库修复的幂等性

*对于任何*数据库状态，多次执行架构修复操作应该产生相同的结果，不会破坏已修复的数据。

**验证：需求 9.2**

### 属性 7：SRS 间隔计算的单调性

*对于任何*SRS 记录，当难度等级为 EASY 或 GOOD 时，下次复习间隔应该大于或等于当前间隔；当难度等级为 HARD 时，间隔应该重置为较小值。

**验证：需求 5.2, 5.3**

### 属性 8：管理员 CRUD 的完整性

*对于任何*管理员账号，创建后应该能够查询到、更新后应该反映新数据、删除后应该无法查询到。

**验证：需求 1.1, 1.2, 1.3, 1.4**

### 属性 9：密码修改的安全性

*对于任何*密码修改请求，只有提供正确的旧密码时才能成功修改，否则应该拒绝。

**验证：需求 1.5**

### 属性 10：返回数据的结构完整性

*对于任何*查询操作，返回的数据对象应该包含所有必需的字段（如考试历史包含学员信息、考试信息和成绩；进度数据包含用户ID、日期和练习数量）。

**验证：需求 3.2, 4.2, 11.2**

### 属性 11：权限验证的严格性

*对于任何*管理员专用路由，非管理员用户访问时应该返回 403 Forbidden 错误；对于任何需要认证的路由，未认证用户访问时应该返回 401 Unauthorized 错误。

**验证：需求 10.2, 10.3**

### 属性 12：错误响应的一致性

*对于任何*错误情况，系统应该返回包含 error 字段的 JSON 对象，并使用适当的 HTTP 状态码。

**验证：需求 10.4, 11.3**

## 错误处理

### 错误类型

1. **认证错误（401 Unauthorized）**
   - 未提供 token
   - token 无效或过期
   - 返回格式：`{ error: "Unauthorized", message: "需要先进行身份认证" }`

2. **权限错误（403 Forbidden）**
   - 非管理员访问管理员路由
   - 返回格式：`{ error: "Forbidden", message: "权限不足" }`

3. **参数错误（400 Bad Request）**
   - 缺少必需参数
   - 参数格式错误
   - 返回格式：`{ error: "参数错误", message: "具体错误信息" }`

4. **资源不存在（404 Not Found）**
   - 查询的资源不存在
   - 返回格式：`{ error: "资源不存在", message: "具体错误信息" }`

5. **服务器错误（500 Internal Server Error）**
   - 数据库错误
   - 未预期的异常
   - 返回格式：`{ error: "服务器错误", message: error.message }`

### 错误处理模式

所有 controller 函数应该使用 try-catch 包裹：

```javascript
async function controllerFunction(req, res) {
  try {
    // 业务逻辑
    const result = await serviceFunction(req.db, params);
    res.json(result);
  } catch (error) {
    console.error('[Module] Error:', error);
    res.status(500).json({ 
      error: '操作失败', 
      message: error.message 
    });
  }
}
```

## 测试策略

### 双重测试方法

我们将使用单元测试和集成测试的组合来确保全面覆盖：

- **单元测试**：验证 service 层的业务逻辑
- **集成测试**：验证完整的 API 端点行为

### 单元测试

**测试框架**：Vitest

**测试文件位置**：`tests/unit/services/`

**测试内容**：
- Service 函数的输入输出
- 边界条件和错误情况
- 数据库查询的正确性（使用 mock）

**示例**：

```javascript
// tests/unit/services/mistake.service.test.js
describe('Mistake Service', () => {
  test('getUserMistakes 应该返回用户的错题列表', async () => {
    const mockDb = createMockDb();
    const result = await getUserMistakes(mockDb, 'user-1');
    expect(Array.isArray(result)).toBe(true);
  });
  
  test('addMistake 应该添加新错题', async () => {
    const mockDb = createMockDb();
    const result = await addMistake(mockDb, 'user-1', 'q-1');
    expect(result.success).toBe(true);
    expect(result.added).toBe(true);
  });
  
  test('addMistake 不应该重复添加已存在的错题', async () => {
    const mockDb = createMockDb();
    await addMistake(mockDb, 'user-1', 'q-1');
    const result = await addMistake(mockDb, 'user-1', 'q-1');
    expect(result.success).toBe(true);
    expect(result.added).toBe(false);
  });
});
```

### 集成测试

**测试框架**：Vitest + Supertest

**测试文件位置**：`tests/integration/`

**测试内容**：
- 完整的 HTTP 请求-响应流程
- 认证和权限验证
- 数据库实际操作（使用测试数据库）

**示例**：

```javascript
// tests/integration/mistake.api.test.js
describe('Mistake API', () => {
  test('GET /api/mistakes 应该返回用户的错题列表', async () => {
    const token = await getAuthToken('student');
    const response = await request(app)
      .get('/api/mistakes')
      .set('Authorization', `Bearer ${token}`)
      .expect(200);
    
    expect(Array.isArray(response.body)).toBe(true);
  });
  
  test('POST /api/mistakes 应该添加错题', async () => {
    const token = await getAuthToken('student');
    const response = await request(app)
      .post('/api/mistakes')
      .set('Authorization', `Bearer ${token}`)
      .send({ questionId: 'q-1' })
      .expect(200);
    
    expect(response.body.success).toBe(true);
  });
  
  test('GET /api/mistakes 未认证时应该返回 401', async () => {
    await request(app)
      .get('/api/mistakes')
      .expect(401);
  });
});
```

### 测试覆盖目标

- **Service 层**：≥ 80% 代码覆盖率
- **Controller 层**：≥ 70% 代码覆盖率
- **集成测试**：覆盖所有 API 端点的主要场景

### 测试执行

```bash
# 运行所有测试
npm test

# 运行单元测试
npm run test:unit

# 运行集成测试
npm run test:integration

# 生成覆盖率报告
npm run test:coverage
```

## 实施注意事项

### 1. 代码复用

- 使用现有的 `parseOptionsField` 和 `parseAnswerField` 工具函数处理题目数据
- 使用现有的认证中间件（`auth`, `adminAuth`）
- 使用现有的错误处理模式

### 2. 数据库操作

- 所有数据库操作通过 `req.db` 访问
- 使用参数化查询防止 SQL 注入
- 使用 PostgreSQL 的 UPSERT 语法（`ON CONFLICT`）处理重复插入

### 3. 字段名转换

- 数据库使用 snake_case（如 `user_id`, `question_id`）
- API 返回使用 camelCase（如 `userId`, `questionId`）
- 在 service 层进行转换

### 4. 日志记录

- 所有操作记录日志，包含用户ID和操作类型
- 错误日志包含完整的错误堆栈
- 使用统一的日志格式：`[Module] Action: details`

### 5. 性能考虑

- 错题和收藏查询使用 JOIN 一次性获取完整题目信息
- 避免 N+1 查询问题
- 对频繁查询的字段添加索引

### 6. 安全考虑

- 所有管理员路由使用 `adminAuth` 中间件
- 密码修改必须验证旧密码
- 敏感信息（如密码）不在日志中记录

## 部署计划

### 1. 开发阶段

1. 创建 service 层函数
2. 编写 service 层单元测试
3. 创建 controller 层函数
4. 创建 routes 层定义
5. 编写集成测试
6. 本地测试验证

### 2. 测试阶段

1. 运行完整测试套件
2. 验证测试覆盖率
3. 手动测试关键功能
4. 性能测试（如需要）

### 3. 部署阶段

1. 更新 `src/routes/index.js` 注册新路由
2. 部署到测试环境
3. 验证所有 API 端点
4. 部署到生产环境
5. 监控错误日志

### 4. 验证清单

- [ ] 所有单元测试通过
- [ ] 所有集成测试通过
- [ ] 测试覆盖率达标
- [ ] 前端功能正常（无 404 错误）
- [ ] 认证和权限验证正常
- [ ] 错误处理正确
- [ ] 日志记录完整
- [ ] 性能符合要求

## 回滚计划

如果部署后发现问题：

1. **立即回滚**：使用 Git 回滚到上一个稳定版本
2. **问题分析**：查看错误日志，定位问题
3. **修复验证**：在开发环境修复并测试
4. **重新部署**：修复后重新部署

## 文档更新

完成实施后需要更新以下文档：

1. **API 文档**：添加新增路由的说明
2. **模块依赖关系图**：更新模块关系
3. **部署指南**：更新部署步骤（如有变化）
4. **测试文档**：记录测试用例和覆盖率
