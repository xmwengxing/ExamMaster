# 实施计划：完整路由迁移

## 概述

本实施计划将系统地补充后端模块化重构中遗漏的路由。任务按照优先级和依赖关系组织，确保每一步都可以独立验证和测试。

## 任务列表

### 阶段 1：错题管理模块（优先级 1）

- [x] 1. 实现错题管理模块
  - [x] 1.1 创建 `src/services/mistake.service.js`
    - 实现 `getUserMistakes(db, userId)` 函数
    - 实现 `addMistake(db, userId, questionId)` 函数
    - 使用 JOIN 查询获取完整题目信息
    - 使用 `parseOptionsField` 和 `parseAnswerField` 处理题目数据
    - _需求: 6.1, 6.2, 6.3_
  
  - [x] 1.2 编写错题服务单元测试
    - 测试 `getUserMistakes` 返回正确的错题列表
    - 测试 `addMistake` 添加新错题
    - 测试 `addMistake` 不重复添加已存在的错题（幂等性）
    - **属性 5：错题添加的幂等性**
    - **验证：需求 6.3**
    - _需求: 12.1_
  
  - [x] 1.3 创建 `src/controllers/mistake.controller.js`
    - 实现 `getMistakes(req, res)` 控制器
    - 实现 `addMistake(req, res)` 控制器
    - 添加错误处理（try-catch）
    - 添加日志记录
    - _需求: 6.1, 6.2_
  
  - [x] 1.4 创建 `src/routes/mistake.routes.js`
    - 定义 GET /api/mistakes 路由（使用 auth 中间件）
    - 定义 POST /api/mistakes 路由（使用 auth 中间件）
    - _需求: 6.1, 6.2, 10.1, 10.3_
  
  - [x] 1.5 编写错题 API 集成测试
    - 测试 GET /api/mistakes 返回用户错题
    - 测试 POST /api/mistakes 添加错题
    - 测试未认证访问返回 401
    - **属性 1：用户数据隔离**
    - **验证：需求 6.1**
    - _需求: 12.2_
  
  - [x] 1.6 在 `src/routes/index.js` 中注册错题路由
    - 导入 `mistakeRoutes`
    - 注册 `app.use('/api/mistakes', mistakeRoutes)`
    - 所有测试通过（11/11）

### 阶段 2：收藏管理模块（优先级 1）

- [x] 2. 实现收藏管理模块
  - [x] 2.1 创建 `src/services/favorite.service.js`
    - 实现 `getUserFavorites(db, userId)` 函数
    - 实现 `toggleFavorite(db, userId, questionId)` 函数
    - 使用 JOIN 查询获取完整题目信息
    - 实现切换逻辑（已收藏则删除，未收藏则添加）
    - _需求: 7.1, 7.2, 7.3, 7.4_
  
  - [x] 2.2 编写收藏服务单元测试
    - 测试 `getUserFavorites` 返回正确的收藏列表
    - 测试 `toggleFavorite` 添加收藏
    - 测试 `toggleFavorite` 取消收藏
    - 测试连续两次切换回到初始状态（往返一致性）
    - **属性 4：收藏切换的往返一致性**
    - **验证：需求 7.4**
    - _需求: 12.1_
  
  - [x] 2.3 创建 `src/controllers/favorite.controller.js`
    - 实现 `getFavorites(req, res)` 控制器
    - 实现 `toggleFavorite(req, res)` 控制器
    - 添加错误处理和日志记录
    - _需求: 7.1, 7.2, 7.3, 7.4_
  
  - [x] 2.4 创建 `src/routes/favorite.routes.js`
    - 定义 GET /api/favorites 路由（使用 auth 中间件）
    - 定义 POST /api/favorites/:qId 路由（使用 auth 中间件）
    - _需求: 7.1, 7.2, 7.3, 7.4, 10.1, 10.3_
  
  - [x] 2.5 编写收藏 API 集成测试
    - 测试 GET /api/favorites 返回用户收藏
    - 测试 POST /api/favorites/:qId 切换收藏状态
    - 测试未认证访问返回 401
    - **属性 1：用户数据隔离**
    - **验证：需求 7.1**
    - _需求: 12.2_
  
  - [x] 2.6 在 `src/routes/index.js` 中注册收藏路由
    - 导入 `favoriteRoutes`
    - 注册 `app.use('/api/favorites', favoriteRoutes)`
    - 所有测试通过（10/10）

### 阶段 3：笔记管理模块（优先级 1）

- [x] 3. 实现笔记管理模块
  - [x] 3.1 创建 `src/services/note.service.js`
    - 实现 `saveNote(db, userId, questionId, content)` 函数
    - 实现 `getNote(db, userId, questionId)` 函数
    - 使用 UPSERT 语法（ON CONFLICT）
    - 内容为空时删除笔记
    - _需求: 8.1, 8.2, 8.3_
  
  - [x] 3.2 编写笔记服务单元测试
    - 测试 `saveNote` 创建新笔记
    - 测试 `saveNote` 更新已有笔记
    - 测试 `saveNote` 删除空内容笔记（边界情况）
    - 测试 `getNote` 返回正确的笔记
    - **属性 2：添加操作的持久化**
    - **验证：需求 8.1**
    - _需求: 12.1_
  
  - [x] 3.3 创建 `src/controllers/note.controller.js`
    - 实现 `saveNote(req, res)` 控制器
    - 实现 `getNote(req, res)` 控制器
    - 添加错误处理和日志记录
    - _需求: 8.1, 8.2_
  
  - [x] 3.4 创建 `src/routes/note.routes.js`
    - 定义 POST /api/notes 路由（使用 auth 中间件）
    - 定义 GET /api/notes/:qId 路由（使用 auth 中间件）
    - _需求: 8.1, 8.2, 10.1, 10.3_
  
  - [x] 3.5 编写笔记 API 集成测试
    - 测试 POST /api/notes 保存笔记
    - 测试 GET /api/notes/:qId 获取笔记
    - 测试未认证访问返回 401
    - _需求: 12.2_
  
  - [x] 3.6 在 `src/routes/index.js` 中注册笔记路由
    - 导入 `noteRoutes`
    - 注册 `app.use('/api/notes', noteRoutes)`
    - 所有测试通过（9/9）

- [x] 4. 检查点 - 核心功能验证
  - 运行所有测试，确保错题、收藏、笔记模块正常工作
  - 所有测试通过（59/59）
    - 单元测试：29/29（错题 9 + 收藏 9 + 笔记 11）
    - 集成测试：30/30（错题 11 + 收藏 10 + 笔记 9）
  - ✅ 核心功能验证完成

### 阶段 4：SRS 模块扩展（优先级 1）

- [x] 5. 扩展 SRS 模块
  - [x] 5.1 更新 `src/services/srs.service.js`
    - 已存在 `getSRSRecords(db, userId)` 函数
    - 已存在 `updateSRSRecord` 函数
    - SRS 更新逻辑已完整实现
    - _需求: 5.1, 5.2, 5.3_
  
  - [x] 5.2 编写 SRS 服务单元测试
    - 测试 `getSRSRecords` 返回用户的 SRS 记录
    - 测试 SRS 间隔计算的正确性（HARD/GOOD/EASY）
    - 测试间隔的单调性（GOOD/EASY 时间隔增加）
    - **属性 7：SRS 间隔计算的单调性**
    - **验证：需求 5.2, 5.3**
    - _需求: 12.1_
  
  - [x] 5.3 创建 `src/controllers/srs.controller.js`
    - 实现 `getSRSRecordsController(req, res)` 控制器
    - 实现 `updateSRSRecordController(req, res)` 控制器
    - 添加错误处理和日志记录
    - _需求: 5.1, 10.1, 10.3_
  
  - [x] 5.4 创建 `src/routes/srs.routes.js`
    - 定义 GET /api/srs/records 路由（使用 auth 中间件）
    - 定义 POST /api/srs/records 路由（使用 auth 中间件）
    - _需求: 5.1, 10.1, 10.3_
  
  - [x] 5.5 编写 SRS API 集成测试
    - 测试 GET /api/srs/records 返回用户 SRS 记录
    - 测试 POST /api/srs/records 更新 SRS 记录
    - 测试未认证访问返回 401
    - **属性 1：用户数据隔离**
    - **验证：需求 5.1**
    - _需求: 12.2_
  
  - [x] 5.6 在 `src/routes/index.js` 中注册 SRS 路由
    - 导入 `srsRoutes`
    - 注册 `app.use('/api/srs', srsRoutes)`
    - 所有测试通过（13 单元 + 12 集成 = 25/25）

### 阶段 5：管理员账号管理（优先级 2）

- [x] 6. 扩展管理员模块 - 账号管理
  - [x] 6.1 更新 `src/services/admin.service.js`
    - 已实现 `getAllAdmins(db)` 函数
    - 已实现 `createAdmin(db, adminData)` 函数
    - 已实现 `updateAdmin(db, adminId, updates)` 函数
    - 已实现 `deleteAdmin(db, adminId)` 函数
    - 已实现 `changeAdminPassword(db, adminId, oldPassword, newPassword)` 函数
    - 密码使用 bcrypt 加密
    - _需求: 1.1, 1.2, 1.3, 1.4, 1.5_
  
  - [x] 6.2 编写管理员服务单元测试
    - ✅ 测试 `getAllAdmins` 返回所有管理员
    - ✅ 测试 `createAdmin` 创建新管理员
    - ✅ 测试 `updateAdmin` 更新管理员信息
    - ✅ 测试 `deleteAdmin` 删除管理员
    - ✅ 测试 `changeAdminPassword` 验证旧密码
    - ✅ 测试 `changeAdminPassword` 拒绝错误的旧密码
    - **属性 8：管理员 CRUD 的完整性**
    - **属性 9：密码修改的安全性**
    - **验证：需求 1.1, 1.2, 1.3, 1.4, 1.5**
    - 所有测试通过（20/20）
    - _需求: 12.1_
  
  - [x] 6.3 更新 `src/controllers/admin.controller.js`
    - 已实现 `getAdmins(req, res)` 控制器
    - 已实现 `createAdmin(req, res)` 控制器
    - 已实现 `updateAdmin(req, res)` 控制器
    - 已实现 `deleteAdmin(req, res)` 控制器
    - 已实现 `changePassword(req, res)` 控制器
    - 添加错误处理和日志记录
    - _需求: 1.1, 1.2, 1.3, 1.4, 1.5_
  
  - [x] 6.4 更新 `src/routes/admin.routes.js`
    - 已添加 GET /api/admin/admins 路由（使用 adminAuth 中间件）
    - 已添加 POST /api/admin/admins 路由（使用 adminAuth 中间件）
    - 已添加 PUT /api/admin/admins/:id 路由（使用 adminAuth 中间件）
    - 已添加 DELETE /api/admin/admins/:id 路由（使用 adminAuth 中间件）
    - 已添加 POST /api/admin/change-password 路由（使用 adminAuth 中间件）
    - _需求: 1.1, 1.2, 1.3, 1.4, 1.5, 10.1, 10.2_
  
  - [x] 6.5 编写管理员账号 API 集成测试
    - ✅ 创建测试文件 `tests/integration/admin.api.test.js`
    - ✅ 测试 GET /api/admin/admins 返回管理员列表
    - ✅ 测试 POST /api/admin/admins 创建管理员
    - ✅ 测试 PUT /api/admin/admins/:id 更新管理员
    - ✅ 测试 DELETE /api/admin/admins/:id 删除管理员
    - ✅ 测试 POST /api/admin/change-password 修改密码
    - ✅ 测试非管理员访问返回 403
    - **属性 11：权限验证的严格性**
    - **验证：需求 10.2**
    - ✅ 所有测试通过（22/22）
    - _需求: 12.2_

### 阶段 6：考试历史和进度管理（优先级 2）

- [x] 7. 扩展管理员模块 - 考试历史和进度
  - [x] 7.1 更新 `src/services/admin.service.js`
    - 已实现 `getAllExamHistory(db)` 函数
    - 已实现 `getAllProgress(db)` 函数
    - 考试历史已 JOIN users 表获取学员信息
    - _需求: 3.1, 3.2, 4.1, 4.2_
  
  - [x] 7.2 编写考试历史和进度服务单元测试
    - ✅ 测试 `getAllExamHistory` 返回所有考试历史
    - ✅ 测试返回数据包含学员信息、考试信息和成绩
    - ✅ 测试 `getAllProgress` 返回所有进度数据
    - ✅ 测试返回数据包含用户ID、日期和练习数量
    - **属性 10：返回数据的结构完整性**
    - **验证：需求 3.2, 4.2**
    - 包含在管理员服务单元测试中（20/20通过）
    - _需求: 12.1_
  
  - [x] 7.3 更新 `src/controllers/admin.controller.js`
    - 已实现 `getExamHistory(req, res)` 控制器
    - 已实现 `getAllProgress(req, res)` 控制器
    - 添加错误处理和日志记录
    - _需求: 3.1, 4.1_
  
  - [x] 7.4 更新 `src/routes/admin.routes.js`
    - 已添加 GET /api/admin/exam-history 路由（使用 adminAuth 中间件）
    - 已添加 GET /api/admin/all-progress 路由（使用 adminAuth 中间件）
    - _需求: 3.1, 4.1, 10.1, 10.2_
  
  - [x] 7.5 编写考试历史和进度 API 集成测试
    - ✅ 测试 GET /api/admin/exam-history 返回考试历史
    - ✅ 测试 GET /api/admin/all-progress 返回进度数据
    - ✅ 测试非管理员访问返回 403
    - 包含在管理员API集成测试中（22/22通过）
    - _需求: 12.2_

### 阶段 7：数据库修复功能（优先级 2）

- [x] 8. 实现数据库修复功能
  - [x] 8.1 更新 `src/services/admin.service.js`
    - 已实现 `repairStudentSchema(db)` 函数
    - 实现幂等的修复逻辑（可重复执行）
    - 检测并修复双重编码的权限字段
    - 返回修复的记录数量
    - _需求: 9.1, 9.2_
  
  - [x] 8.2 编写数据库修复服务单元测试
    - ✅ 测试 `repairStudentSchema` 修复双重编码问题
    - ✅ 测试多次执行产生相同结果（幂等性）
    - **属性 6：数据库修复的幂等性**
    - **验证：需求 9.2**
    - 包含在管理员服务单元测试中（20/20通过）
    - _需求: 12.1_
  
  - [x] 8.3 更新 `src/controllers/admin.controller.js`
    - 已实现 `repairStudentSchema(req, res)` 控制器
    - 添加错误处理和日志记录
    - _需求: 9.1_
  
  - [x] 8.4 更新 `src/routes/admin.routes.js`
    - 已添加 POST /api/admin/repair-student-schema 路由（使用 adminAuth 中间件）
    - _需求: 9.1, 10.1, 10.2_
  
  - [x] 8.5 编写数据库修复 API 集成测试
    - ✅ 测试 POST /api/admin/repair-student-schema 执行修复
    - ✅ 测试非管理员访问返回 403
    - 包含在管理员API集成测试中（22/22通过）
    - _需求: 12.2_

- [x] 9. 检查点 - 管理功能验证
  - ✅ 管理员服务单元测试全部通过（20/20）
  - ✅ 管理员API集成测试全部通过（22/22）
  - ✅ 所有功能已实现并通过测试验证
  - ✅ 总测试数：606个（605通过，1失败已修复）

### 阶段 8：日志管理模块（优先级 3）

- [x] 10. 实现日志管理模块
  - [x] 10.1 创建 `src/services/log.service.js`
    - ✅ 实现 `getLoginLogs(db)` 函数
    - ✅ 实现 `getAuditLogs(db)` 函数
    - ✅ 实现 `createAuditLog(db, logData)` 函数
    - _需求: 2.1, 2.2, 2.3_
  
  - [x] 10.2 编写日志服务单元测试
    - ✅ 测试 `getLoginLogs` 返回登录日志
    - ✅ 测试 `getAuditLogs` 返回审计日志
    - ✅ 测试 `createAuditLog` 创建审计日志
    - ✅ 包含在管理员服务单元测试中（26/26通过）
    - _需求: 12.1_
  
  - [x] 10.3 创建 `src/controllers/log.controller.js`
    - ✅ 实现 `getLoginLogs(req, res)` 控制器
    - ✅ 实现 `getAuditLogs(req, res)` 控制器
    - ✅ 实现 `createAuditLog(req, res)` 控制器
    - ✅ 添加错误处理和日志记录
    - _需求: 2.1, 2.2, 2.3_
  
  - [x] 10.4 创建 `src/routes/log.routes.js`
    - ✅ 定义 GET /api/admin/login-logs 路由（使用 adminAuth 中间件）
    - ✅ 定义 GET /api/admin/audit-logs 路由（使用 adminAuth 中间件）
    - ✅ 定义 POST /api/admin/audit-logs 路由（使用 adminAuth 中间件）
    - ✅ 日志路由已集成到管理员路由中
    - _需求: 2.1, 2.2, 2.3, 10.1, 10.2_
  
  - [x] 10.5 编写日志 API 集成测试
    - ✅ 测试 GET /api/admin/login-logs 返回登录日志
    - ✅ 测试 GET /api/admin/audit-logs 返回审计日志
    - ✅ 测试 POST /api/admin/audit-logs 创建审计日志
    - ✅ 测试非管理员访问返回 403
    - ✅ 包含在管理员API集成测试中（29/29通过）
    - _需求: 12.2_

### 阶段 9：路由注册和集成

- [x] 11. 更新路由注册
  - [x] 11.1 更新 `src/routes/index.js`
    - ✅ 导入新的路由模块（mistake, favorite, note, srs）
    - ✅ 注册错题路由：`app.use('/api/mistakes', mistakeRoutes)`
    - ✅ 注册收藏路由：`app.use('/api/favorites', favoriteRoutes)`
    - ✅ 注册笔记路由：`app.use('/api/notes', noteRoutes)`
    - ✅ 注册 SRS 路由：`app.use('/api/srs', srsRoutes)`
    - ✅ 日志路由已集成到管理员路由中
    - ✅ 验证所有路由前缀正确
    - _需求: 10.1_
  
  - [x] 11.2 验证中间件应用
    - ✅ 确认所有学员路由使用 `auth` 中间件
    - ✅ 确认所有管理员路由使用 `auth` 和 `adminAuth` 中间件
    - ✅ 确认数据库中间件已注入（`req.db` 可用）
    - _需求: 10.1, 10.2, 10.3_

### 阶段 10：完整测试和验证

- [x] 12. 运行完整测试套件
  - [x] 12.1 运行所有单元测试
    - ✅ 执行 `npm test`
    - ✅ 所有单元测试通过
    - ✅ 测试覆盖率达标（Service 层 ≥ 80%）
    - _需求: 12.3_
  
  - [x] 12.2 运行所有集成测试
    - ✅ 执行 `npm test`
    - ✅ 所有集成测试通过（包括日志管理）
    - ✅ 验证所有 API 端点正常工作
    - _需求: 12.3_
  
  - [x] 12.3 生成测试覆盖率报告
    - ✅ 总测试数：619个测试全部通过
    - ✅ 单元测试：包含所有服务层测试
    - ✅ 集成测试：包含所有API端点测试
    - ✅ 管理员模块：29个集成测试全部通过
    - _需求: 12.1, 12.2_

- [x] 13. 手动功能验证
  - [x] 13.1 启动本地开发环境
    - 使用 `docker compose up -d` 启动服务
    - 验证所有容器正常运行
  
  - [x] 13.2 测试核心功能（优先级 1）
    - 测试错题添加和查询
    - 测试收藏切换和查询
    - 测试笔记保存和查询
    - 测试 SRS 记录查询
    - 验证前端不再出现 404 错误
  
  - [x] 13.3 测试管理功能（优先级 2）
    - 测试管理员账号管理
    - 测试考试历史查询
    - 测试进度数据查询
    - 测试数据库修复功能
  
  - [x] 13.4 测试日志功能（优先级 3）
    - 测试登录日志查询
    - 测试审计日志查询和创建

- [x] 14. 最终检查点
  - 确认所有测试通过（492+ 个测试）
  - 确认前端功能正常（无 404/401 错误）
  - 确认代码质量符合标准
  - 询问用户是否准备部署

### 阶段 11：部署和验证

- [x] 15. 部署到生产环境
  - [x] 15.1 提交代码到 Git
    - ✅ 使用有意义的提交信息
    - ✅ 推送到远程仓库
  
  - [x] 15.2 执行部署脚本
    - ✅ 运行 `quick-deploy.bat`
    - ✅ 前端构建成功
    - ✅ 文件同步到服务器
    - ✅ Docker镜像重新构建
    - ✅ API容器启动成功（healthy状态）
    - ✅ 健康检查通过
  
  - [x] 15.3 生产环境验证
    - ✅ 访问生产环境 URL (https://exammaster.zzzjl.com)
    - ✅ 健康检查通过（数据库连接正常）
    - ✅ 权限控制正常（401响应）
    - ✅ 所有新增路由已注册（错题、收藏、SRS）
    - ✅ 服务器日志无错误

- [x] 16. 文档更新
  - [x] 16.1 更新 `docs/模块化遗漏路由清单.md`
    - ✅ 将所有路由标记为已完成
    - ✅ 添加完成日期和验证结果
    - ✅ 添加技术实现说明
    - ✅ 添加后续建议
  
  - [x] 16.2 创建完成总结文档
    - ✅ 创建 `docs/路由迁移完成总结.md`
    - ✅ 记录实施过程和完成的功能模块
    - ✅ 记录遇到的问题和解决方案
    - ✅ 记录测试结果和覆盖率（619个测试，100%通过）
    - ✅ 记录部署信息和验证结果
    - ✅ 总结技术亮点和经验教训

## 注意事项

### 代码风格

- 使用现有项目的代码风格
- 所有注释使用中文
- 函数和变量命名使用英文
- 保持与现有模块的一致性

### 错误处理

- 所有 controller 函数使用 try-catch
- 错误日志包含模块名和操作类型
- 返回统一的错误格式

### 测试要求

- 每个 service 函数至少有 2-3 个测试用例
- 每个 API 端点至少有 2-3 个集成测试
- 测试覆盖正常情况、边界情况和错误情况

### 性能考虑

- 使用 JOIN 避免 N+1 查询
- 对频繁查询的字段添加索引
- 避免在循环中执行数据库查询

### 安全考虑

- 所有管理员路由使用 adminAuth 中间件
- 密码使用 bcrypt 加密
- 使用参数化查询防止 SQL 注入
- 敏感信息不记录在日志中

## 测试任务说明

所有测试任务都是必须执行的，以确保代码质量和系统稳定性。测试覆盖包括：
- **单元测试**：验证 service 层的业务逻辑（目标覆盖率 ≥ 80%）
- **集成测试**：验证完整的 API 端点行为（覆盖所有主要场景）

这些测试将帮助我们：
- 及早发现和修复 bug
- 确保代码重构不会破坏现有功能
- 提供代码质量的可靠保证
- 简化未来的维护工作
