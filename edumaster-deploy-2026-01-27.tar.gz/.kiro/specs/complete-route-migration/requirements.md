# 需求文档：完整路由迁移

## 简介

本规范旨在完成后端模块化重构中遗漏的路由迁移工作。在之前的模块化重构中（从单体 `server.js` 4100+ 行拆分为 `src/` 目录的模块化架构），部分路由被遗漏，导致前端请求返回 404 或 401 错误。本规范将系统地识别、分类并实现所有缺失的路由。

## 术语表

- **System**: 教育管理系统后端服务
- **Route**: API 路由端点
- **Service**: 业务逻辑服务层
- **Controller**: 控制器层，处理 HTTP 请求和响应
- **Middleware**: 中间件，用于认证、授权等
- **Admin**: 管理员角色用户
- **Student**: 学员角色用户

## 需求

### 需求 1：管理员账号管理

**用户故事：** 作为管理员，我想要管理其他管理员账号，以便控制系统的管理权限。

#### 验收标准

1. WHEN 管理员请求获取管理员列表 THEN THE System SHALL 返回所有管理员账号信息
2. WHEN 管理员创建新管理员账号 THEN THE System SHALL 验证数据并创建账号
3. WHEN 管理员更新管理员账号信息 THEN THE System SHALL 更新指定账号的信息
4. WHEN 管理员删除管理员账号 THEN THE System SHALL 删除指定账号
5. WHEN 管理员修改自己的密码 THEN THE System SHALL 验证旧密码并更新新密码

### 需求 2：日志管理

**用户故事：** 作为管理员，我想要查看系统日志，以便监控系统使用情况和排查问题。

#### 验收标准

1. WHEN 管理员请求登录日志 THEN THE System SHALL 返回所有用户的登录记录
2. WHEN 管理员请求审计日志 THEN THE System SHALL 返回系统操作审计记录
3. WHEN 管理员创建审计日志 THEN THE System SHALL 记录操作信息

### 需求 3：考试历史管理

**用户故事：** 作为管理员，我想要查看所有学员的考试历史，以便分析学习效果和考试情况。

#### 验收标准

1. WHEN 管理员请求所有考试历史 THEN THE System SHALL 返回所有学员的考试记录
2. WHEN 返回考试历史 THEN THE System SHALL 包含学员信息、考试信息和成绩

### 需求 4：进度管理

**用户故事：** 作为管理员，我想要查看所有学员的学习进度，以便了解整体学习情况。

#### 验收标准

1. WHEN 管理员请求所有学员进度 THEN THE System SHALL 返回每日进度统计数据
2. WHEN 返回进度数据 THEN THE System SHALL 包含用户ID、日期和练习数量

### 需求 5：SRS 间隔重复系统

**用户故事：** 作为学员，我想要使用间隔重复系统复习题目，以便提高记忆效果。

#### 验收标准

1. WHEN 学员请求 SRS 记录 THEN THE System SHALL 返回该学员的所有 SRS 记录
2. WHEN 学员更新 SRS 记录 THEN THE System SHALL 根据难度等级计算下次复习时间
3. WHEN 计算复习间隔 THEN THE System SHALL 使用 SM-2 算法或类似算法

### 需求 6：错题管理

**用户故事：** 作为学员，我想要管理我的错题集，以便针对性地复习薄弱知识点。

#### 验收标准

1. WHEN 学员请求错题列表 THEN THE System SHALL 返回该学员标记的所有错题
2. WHEN 学员添加错题 THEN THE System SHALL 将题目添加到错题集
3. WHEN 题目已在错题集中 THEN THE System SHALL 不重复添加

### 需求 7：收藏管理

**用户故事：** 作为学员，我想要收藏重要题目，以便快速访问和复习。

#### 验收标准

1. WHEN 学员请求收藏列表 THEN THE System SHALL 返回该学员收藏的所有题目
2. WHEN 学员收藏题目 THEN THE System SHALL 添加收藏记录
3. WHEN 学员取消收藏 THEN THE System SHALL 删除收藏记录
4. WHEN 题目已收藏时再次收藏 THEN THE System SHALL 取消收藏（切换状态）

### 需求 8：笔记管理

**用户故事：** 作为学员，我想要为题目添加笔记，以便记录学习心得和要点。

#### 验收标准

1. WHEN 学员保存笔记 THEN THE System SHALL 创建或更新笔记记录
2. WHEN 学员查询笔记 THEN THE System SHALL 返回指定题目的笔记
3. WHEN 笔记内容为空 THEN THE System SHALL 删除笔记记录

### 需求 9：数据库架构修复

**用户故事：** 作为管理员，我想要修复数据库中的历史数据问题，以便确保系统正常运行。

#### 验收标准

1. WHEN 管理员执行架构修复 THEN THE System SHALL 修复学员权限字段的双重编码问题
2. WHEN 修复操作执行 THEN THE System SHALL 保持操作幂等性（可重复执行）

### 需求 10：路由注册和中间件

**用户故事：** 作为开发者，我想要所有路由正确注册并应用适当的中间件，以便确保系统安全和功能完整。

#### 验收标准

1. WHEN 路由被注册 THEN THE System SHALL 应用适当的认证中间件
2. WHEN 管理员路由被访问 THEN THE System SHALL 验证管理员权限
3. WHEN 学员路由被访问 THEN THE System SHALL 验证学员身份
4. WHEN 路由处理失败 THEN THE System SHALL 返回适当的错误信息

### 需求 11：向后兼容性

**用户故事：** 作为系统维护者，我想要确保新实现的路由与原有实现完全兼容，以便前端无需修改。

#### 验收标准

1. WHEN 实现新路由 THEN THE System SHALL 保持与原 server.js 相同的 API 接口
2. WHEN 返回数据 THEN THE System SHALL 使用相同的数据格式和字段名
3. WHEN 处理错误 THEN THE System SHALL 返回相同的错误码和错误信息

### 需求 12：测试覆盖

**用户故事：** 作为开发者，我想要为所有新实现的路由编写测试，以便确保代码质量和功能正确性。

#### 验收标准

1. WHEN 实现新的 service 函数 THEN THE System SHALL 包含对应的单元测试
2. WHEN 实现新的 API 路由 THEN THE System SHALL 包含对应的集成测试
3. WHEN 运行测试 THEN THE System SHALL 所有测试通过

## 路由清单

### 优先级 1（核心功能）

#### 错题管理
- GET /api/mistakes - 获取错题列表
- POST /api/mistakes - 添加错题

#### 收藏管理
- GET /api/favorites - 获取收藏列表
- POST /api/favorites/:qId - 添加/取消收藏

#### SRS 记录
- GET /api/srs/records - 获取 SRS 记录
- POST /api/srs/update - 更新 SRS 记录（已存在，需验证）

#### 笔记管理
- POST /api/notes - 保存/删除笔记
- GET /api/notes/:qId - 查询笔记

### 优先级 2（管理功能）

#### 管理员账号管理
- GET /api/admin/admins - 获取管理员列表
- POST /api/admin/admins - 创建管理员
- PUT /api/admin/admins/:id - 更新管理员
- DELETE /api/admin/admins/:id - 删除管理员
- POST /api/admin/change-password - 管理员修改密码

#### 考试历史管理
- GET /api/admin/exam-history - 管理员获取所有考试历史

#### 进度管理
- GET /api/admin/all-progress - 获取所有学员进度

#### 数据库修复
- POST /api/admin/repair-student-schema - 修复学生权限字段

### 优先级 3（日志功能）

#### 日志管理
- GET /api/admin/login-logs - 获取登录日志
- GET /api/admin/audit-logs - 获取审计日志
- POST /api/admin/audit-logs - 创建审计日志

## 实施约束

1. 所有新实现的路由必须与 server.js 中的原实现保持 API 兼容
2. 必须使用现有的认证中间件（auth, adminAuth）
3. 必须使用现有的数据库连接池（req.db）
4. 必须遵循现有的错误处理模式
5. 必须编写单元测试和集成测试
6. 必须更新路由注册文件（src/routes/index.js）
7. 必须保持代码风格与现有模块一致
